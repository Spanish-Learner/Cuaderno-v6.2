// src/engine/lessonGenerator.js
import { getLanguageEngine } from "./databaseLoader";
import { getTutorEngine } from "./tutorEngine";
import { loadStudent } from "./studentModel";

// ============================================================
// LESSON STRUCTURE
// ============================================================

export function createLesson(topic, level = "A1") {
  return {
    id: `lesson_${Date.now()}`,
    title: "",
    objective: "",
    level,
    topic,
    explanation: "",
    examples: [],
    practice: [],
    quiz: [],
    review: [],
    generatedAt: new Date().toISOString()
  };
}

// ============================================================
// LESSON GENERATOR
// ============================================================

export function generateLesson(topic, student = null) {
  const engine = getLanguageEngine();
  const studentData = student || loadStudent();
  const level = studentData.level || "A1";
  
  // Get topic-specific vocabulary
  const vocabulary = getTopicVocabulary(topic, level);
  
  // Build the lesson
  const lesson = createLesson(topic, level);
  
  // Set title and objective
  lesson.title = formatTopicTitle(topic);
  lesson.objective = `Learn to use ${topic} in everyday Spanish.`;
  
  // Generate explanation
  lesson.explanation = generateExplanation(topic, vocabulary);
  
  // Generate examples
  lesson.examples = generateExamples(topic, vocabulary, level);
  
  // Generate practice exercises
  lesson.practice = generatePractice(topic, vocabulary, level);
  
  // Generate quiz questions
  lesson.quiz = generateQuiz(topic, vocabulary, level);
  
  // Generate review flashcards
  lesson.review = generateReview(vocabulary);

  // Build the unified step sequence LessonView renders
  lesson.steps = buildSteps(lesson);
  
  return lesson;
}

// ============================================================
// STEP SEQUENCE (consumed by LessonView)
// ============================================================

function buildSteps(lesson) {
  const steps = [];

  if (lesson.explanation) {
    steps.push({ type: "explanation", content: lesson.explanation });
  }

  (lesson.examples || []).forEach(example => {
    steps.push({ type: "example", spanish: example.spanish, english: example.english });
  });

  (lesson.practice || []).forEach(item => {
    steps.push({ type: "practice", question: item.question, answer: item.answer });
  });

  return steps;
}

// ============================================================
// TOPIC VOCABULARY
// ============================================================

function getTopicVocabulary(topic, level) {
  const engine = getLanguageEngine();
  const topics = {
    "present tense": ["hablar", "comer", "vivir", "ser", "estar", "tener"],
    "past tense": ["ir", "comer", "hablar", "hacer", "decir", "ver"],
    "future tense": ["ir", "hacer", "comer", "tener", "poder", "querer"],
    "food": ["comer", "beber", "tomar", "pan", "agua", "fruta", "queso", "leche"],
    "travel": ["viajar", "ir", "llegar", "hotel", "aeropuerto", "país", "ciudad"],
    "family": ["familia", "madre", "padre", "hermano", "hermana", "hijo", "hija"],
    "greetings": ["hola", "buenos días", "buenas tardes", "buenas noches", "gracias", "por favor"],
    "colors": ["rojo", "azul", "verde", "amarillo", "blanco", "negro", "naranja"],
    "animals": ["perro", "gato", "pájaro", "caballo", "vaca", "pez", "león"],
    "daily life": ["casa", "escuela", "trabajo", "amigo", "familia", "comida", "agua"]
  };
  
  const words = topics[topic] || [];
  return words.map(word => engine.getWord(word)).filter(Boolean);
}

// ============================================================
// TITLE FORMATTING
// ============================================================

function formatTopicTitle(topic) {
  const titles = {
    "present tense": "Present Tense Verbs",
    "past tense": "Past Tense Verbs",
    "future tense": "Future Tense Verbs",
    "food": "Food & Drink",
    "travel": "Travel & Places",
    "family": "Family & People",
    "greetings": "Greetings & Basics",
    "colors": "Colors & Descriptions",
    "animals": "Animals",
    "daily life": "Daily Life"
  };
  return titles[topic] || topic.charAt(0).toUpperCase() + topic.slice(1);
}

// ============================================================
// EXPLANATION GENERATOR
// ============================================================

function generateExplanation(topic, vocabulary) {
  const explanations = {
    "present tense": `
      In Spanish, present tense verbs describe actions happening now or habitual actions.
      Regular verbs follow predictable patterns:
      - -ar verbs: hablar → hablo, hablas, habla
      - -er verbs: comer → como, comes, come
      - -ir verbs: vivir → vivo, vives, vive
      Some common verbs are irregular and must be memorized:
      - ser: soy, eres, es
      - estar: estoy, estás, está
      - tener: tengo, tienes, tiene
    `,
    "past tense": `
      The preterite tense describes completed actions in the past.
      Regular preterite endings:
      - -ar verbs: hablé, hablaste, habló, hablamos, hablasteis, hablaron
      - -er/-ir verbs: comí, comiste, comió, comimos, comisteis, comieron
      
      Common irregular preterite verbs:
      - ir/ser: fui, fuiste, fue, fuimos, fuisteis, fueron
      - hacer: hice, hiciste, hizo, hicimos, hicisteis, hicieron
      - decir: dije, dijiste, dijo, dijimos, dijisteis, dijeron
    `,
    "future tense": `
      The future tense describes actions that will happen.
      Regular future endings are added to the infinitive:
      - hablaré, hablarás, hablará, hablaremos, hablaréis, hablarán
      
      Irregular future stems:
      - tener → tendré
      - hacer → haré
      - decir → diré
      - poder → podré
    `
  };
  
  return explanations[topic] || `
    This lesson will teach you key vocabulary and phrases related to ${topic}.
    Practice each word and try to use them in sentences.
  `;
}

// ============================================================
// EXAMPLES GENERATOR
// ============================================================

function generateExamples(topic, vocabulary, level) {
  const examples = {
    "present tense": [
      { spanish: "Yo hablo español.", english: "I speak Spanish." },
      { spanish: "Tú comes pizza.", english: "You eat pizza." },
      { spanish: "Ella vive en Madrid.", english: "She lives in Madrid." },
      { spanish: "Nosotros somos estudiantes.", english: "We are students." },
      { spanish: "Ellos tienen una casa grande.", english: "They have a big house." }
    ],
    "past tense": [
      { spanish: "Ayer fui al parque.", english: "Yesterday I went to the park." },
      { spanish: "Comí una pizza deliciosa.", english: "I ate a delicious pizza." },
      { spanish: "Ellos fueron al cine.", english: "They went to the movies." },
      { spanish: "Hice mi tarea ayer.", english: "I did my homework yesterday." },
      { spanish: "Dije la verdad.", english: "I told the truth." }
    ],
    "food": [
      { spanish: "Me gusta la pizza.", english: "I like pizza." },
      { spanish: "El pan es fresco.", english: "The bread is fresh." },
      { spanish: "Bebo agua todos los días.", english: "I drink water every day." },
      { spanish: "La fruta es saludable.", english: "Fruit is healthy." },
      { spanish: "¿Quieres comer algo?", english: "Do you want to eat something?" }
    ],
    "travel": [
      { spanish: "Viajo a España en verano.", english: "I travel to Spain in summer." },
      { spanish: "El aeropuerto está lejos.", english: "The airport is far." },
      { spanish: "Me gusta visitar ciudades nuevas.", english: "I like visiting new cities." },
      { spanish: "El hotel es muy bonito.", english: "The hotel is very pretty." },
      { spanish: "¿Dónde está el pasaporte?", english: "Where is the passport?" }
    ]
  };
  
  return examples[topic] || [
    { spanish: "Esto es un ejemplo.", english: "This is an example." },
    { spanish: "Practica con esta frase.", english: "Practice with this sentence." }
  ];
}

// ============================================================
// PRACTICE EXERCISES
// ============================================================

function generatePractice(topic, vocabulary, level) {
  const practices = {
    "present tense": [
      { type: "fill", question: "Yo ___ (hablar) español.", answer: "hablo" },
      { type: "fill", question: "Tú ___ (comer) una manzana.", answer: "comes" },
      { type: "fill", question: "Ella ___ (vivir) en México.", answer: "vive" },
      { type: "fill", question: "Nosotros ___ (ser) amigos.", answer: "somos" },
      { type: "fill", question: "Ellos ___ (tener) un perro.", answer: "tienen" }
    ],
    "past tense": [
      { type: "fill", question: "Yo ___ (ir) al supermercado.", answer: "fui" },
      { type: "fill", question: "Tú ___ (comer) una pizza.", answer: "comiste" },
      { type: "fill", question: "Ella ___ (hacer) su tarea.", answer: "hizo" },
      { type: "fill", question: "Nosotros ___ (decir) la verdad.", answer: "dijimos" },
      { type: "fill", question: "Ellos ___ (ver) una película.", answer: "vieron" }
    ],
    "food": [
      { type: "translate", question: "I like pizza.", answer: "Me gusta la pizza." },
      { type: "translate", question: "The bread is fresh.", answer: "El pan es fresco." },
      { type: "translate", question: "I drink water.", answer: "Bebo agua." },
      { type: "translate", question: "Fruit is healthy.", answer: "La fruta es saludable." },
      { type: "translate", question: "Do you want to eat?", answer: "¿Quieres comer?" }
    ]
  };
  
  return practices[topic] || [
    { type: "fill", question: "Completa esta frase.", answer: "ejemplo" }
  ];
}

// ============================================================
// QUIZ QUESTIONS
// ============================================================

function generateQuiz(topic, vocabulary, level) {
  const quizzes = {
    "present tense": [
      { question: "What is the correct form of 'hablar' for 'yo'?", options: ["hablo", "hablas", "habla", "hablamos"], answer: "hablo" },
      { question: "What is the correct form of 'comer' for 'tú'?", options: ["como", "comes", "come", "comemos"], answer: "comes" },
      { question: "What is the correct form of 'vivir' for 'ella'?", options: ["vivo", "vives", "vive", "vivimos"], answer: "vive" }
    ],
    "past tense": [
      { question: "What is the preterite form of 'ir' for 'yo'?", options: ["fui", "fuiste", "fue", "fuimos"], answer: "fui" },
      { question: "What is the preterite form of 'comer' for 'ellos'?", options: ["comí", "comiste", "comió", "comieron"], answer: "comieron" },
      { question: "What is the preterite form of 'hacer' for 'tú'?", options: ["hice", "hiciste", "hizo", "hicimos"], answer: "hiciste" }
    ],
    "food": [
      { question: "What is the Spanish word for 'bread'?", options: ["pan", "queso", "agua", "fruta"], answer: "pan" },
      { question: "What is the Spanish word for 'apple'?", options: ["naranja", "plátano", "manzana", "limón"], answer: "manzana" },
      { question: "What is the Spanish word for 'water'?", options: ["leche", "agua", "jugo", "café"], answer: "agua" }
    ]
  };
  
  return quizzes[topic] || [
    { question: "Sample question?", options: ["A", "B", "C", "D"], answer: "A" }
  ];
}

// ============================================================
// REVIEW FLASHCARDS
// ============================================================

function generateReview(vocabulary) {
  return vocabulary.map(word => ({
    front: word.word,
    back: word.english,
    example: word.example || "No example available."
  }));
}

// ============================================================
// ADAPTIVE LESSON GENERATOR
// ============================================================

export function generateAdaptiveLesson() {
  const student = loadStudent();
  const mistakes = student.mistakes;
  
  // Calculate which areas need the most work
  const areas = [
    { topic: "past tense", count: Object.values(mistakes.verbs || {}).reduce((a, b) => a + b, 0) },
    { topic: "present tense", count: Object.values(mistakes.verbs || {}).reduce((a, b) => a + b, 0) },
    { topic: "food", count: student.knownWords.length > 50 ? 10 : 5 },
    { topic: "travel", count: student.knownWords.length > 100 ? 15 : 8 },
    { topic: "family", count: 5 },
    { topic: "greetings", count: student.knownWords.length > 20 ? 3 : 8 },
    { topic: "colors", count: 4 },
    { topic: "animals", count: 6 },
    { topic: "daily life", count: student.knownWords.length > 30 ? 12 : 7 }
  ];
  
  // Sort by priority (higher count = more needed)
  areas.sort((a, b) => b.count - a.count);
  
  // Pick the top area
  const primaryTopic = areas[0];
  
  // Generate the lesson
  const lesson = generateLesson(primaryTopic.topic, student);
  
  // Add adaptive elements
  lesson.studentLevel = student.level;
  lesson.studentAccuracy = student.accuracy;
  lesson.recommendedFor = `Based on your profile: ${primaryTopic.count} mistakes in this area`;
  
  return lesson;
}

// ============================================================
// CONTEXT-AWARE LESSON
// ============================================================

export function generateContextLesson(context) {
  // If the user recently talked about food, generate a food lesson
  // If they made past tense errors, generate a past tense lesson
  
  const topics = ["present tense", "past tense", "future tense", "food", "travel", "family"];
  let topic = "daily life";
  
  if (context && context.conversationHistory) {
    const history = context.conversationHistory;
    const lastMessages = history.slice(-5);
    
    // Check for topic indicators
    for (const msg of lastMessages) {
      if (msg.includes("comida") || msg.includes("comer")) topic = "food";
      if (msg.includes("viaj") || msg.includes("hotel")) topic = "travel";
      if (msg.includes("famil") || msg.includes("hermano")) topic = "family";
      if (msg.includes("ayer") || msg.includes("fui")) topic = "past tense";
      if (msg.includes("mañana") || msg.includes("iré")) topic = "future tense";
    }
  }
  
  return generateLesson(topic);
}

// ============================================================
// SINGLETON ACCESSOR (used by the engine manifest)
// ============================================================

let lessonGeneratorInstance = null;

export function getLessonGenerator() {
  if (!lessonGeneratorInstance) {
    lessonGeneratorInstance = {
      createLesson,
      generateLesson,
      generateAdaptiveLesson,
      generateContextLesson
    };
  }
  return lessonGeneratorInstance;
}