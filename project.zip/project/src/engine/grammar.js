// src/engine/grammar.js
import { parseSentence } from "./parser";
import { resolveConjugation } from "./conjugationResolver";
import { subjects } from "../data/subjects";

// ==============================
// BASIC REPLACEMENT RULES
// ==============================

const replacements = [
  { wrong: /\byo fue\b/gi, correct: "yo fui", reason: 'After "yo", use "fui" (first-person past of "ir").' },
  { wrong: /\byo gusto\b/gi, correct: "me gusta", reason: 'Use "me gusta", not "yo gusto".' },
  { wrong: /\btu\b/g, correct: "tú", reason: 'Use "tú" (with an accent) for the pronoun.' },
  { wrong: /\bcomo estas\b/gi, correct: "¿Cómo estás?", reason: "Missing accents and opening question mark." },
  { wrong: /\bpor que\b/gi, correct: "por qué", reason: '"por qué" needs an accent in questions.' },
  { wrong: /\bporque\b/gi, correct: "porque", reason: 'Use "porque" (without accent) for "because".' },
  { wrong: /\bel\b(?=\s+[aá]\s+)/gi, correct: "él", reason: 'Use "él" (with accent) for the pronoun "he".' },
];

// ==============================
// HELPERS
// ==============================

function capitalize(text) {
  if (!text.length) return text;
  return text.charAt(0).toUpperCase() + text.slice(1);
}

function addQuestionMarks(text) {
  if (
    /(como|qué|quien|donde|cuando|por qué|cuál)/i.test(text) &&
    !text.includes("¿")
  ) {
    text = "¿" + text;
  }
  if (text.startsWith("¿") && !text.endsWith("?")) {
    text += "?";
  }
  return text;
}

// ==============================
// SUBJECT-VERB AGREEMENT CHECK
// ==============================

function checkSubjectVerbAgreement(subject, verbForm) {
  if (!subject || !verbForm) return null;
  
  const subjData = subjects[subject.toLowerCase()];
  if (!subjData) return null;
  
  const verbData = resolveConjugation(verbForm);
  if (!verbData) return null;
  
  // Check if the verb form matches the subject's person
  // This is a simplified check - full implementation would map person/number to verb endings
  const personMap = {
    "yo": 1,
    "tú": 2,
    "él": 3,
    "ella": 3,
    "usted": 3,
    "nosotros": 1,
    "ellos": 3,
    "ellas": 3
  };
  
  const expectedPerson = personMap[subject.toLowerCase()];
  
  // For now, we'll just check if the verb exists in our conjugation index
  // Full person/number validation will be added in a future phase
  if (verbData) {
    return {
      valid: true,
      verb: verbData.base,
      tense: verbData.tense,
      subject: subject.toLowerCase(),
      person: expectedPerson
    };
  }
  
  return null;
}

// ==============================
// MAIN CORRECTION FUNCTION
// ==============================

export function correctSentence(sentence) {
  let corrected = sentence.trim();
  const reasons = [];

  // Apply basic replacement rules
  for (const rule of replacements) {
    if (rule.wrong.test(corrected)) {
      corrected = corrected.replace(rule.wrong, rule.correct);
      reasons.push(rule.reason);
    }
  }

  // Parse the sentence for deeper grammar checks
  const parse = parseSentence(corrected);
  const { structure } = parse;

  // Check subject-verb agreement
  if (structure.subject && structure.verb) {
    const validation = checkSubjectVerbAgreement(
      structure.subject.word,
      structure.verb.form
    );
    
    if (validation && validation.verb) {
      // Check if the verb form is appropriate for the subject
      // This is a placeholder - full implementation would generate the correct form
      if (validation.person) {
        // Example: if subject is "yo" and verb is "fue", suggest "fui"
        const correctFormMap = {
          "yo": { "fue": "fui", "era": "era", "estaba": "estaba" },
          "tú": { "fue": "fuiste", "era": "eras", "estaba": "estabas" },
          "él": { "fue": "fue", "era": "era", "estaba": "estaba" },
          "ella": { "fue": "fue", "era": "era", "estaba": "estaba" },
          "usted": { "fue": "fue", "era": "era", "estaba": "estaba" },
          "nosotros": { "fue": "fuimos", "era": "éramos", "estaba": "estábamos" },
          "ellos": { "fue": "fueron", "era": "eran", "estaba": "estaban" },
          "ellas": { "fue": "fueron", "era": "eran", "estaba": "estaban" }
        };
        
        const correctForm = correctFormMap[validation.subject]?.[structure.verb.form.toLowerCase()];
        if (correctForm && correctForm !== structure.verb.form) {
          reasons.push(
            `"${structure.verb.form}" doesn't match subject "${structure.subject.word}". ` +
            `Try "${correctForm}" instead.`
          );
          // Replace in corrected text
          corrected = corrected.replace(
            structure.verb.form,
            correctForm
          );
        }
      }
    }
  }

  // Apply basic corrections
  corrected = capitalize(corrected);
  corrected = addQuestionMarks(corrected);

  // Add final punctuation if missing
  if (corrected.length && !/[.!?]$/.test(corrected)) {
    corrected += ".";
  }

  return {
    original: sentence,
    corrected,
    reasons,
    parsed: structure
  };
}

// ==============================
// EXPLANATION GENERATOR
// ==============================

export function explainCorrection(correction) {
  if (!correction || correction.reasons.length === 0) {
    return {
      explanation: "No correction needed. ¡Perfecto!",
      examples: [],
      practice: null
    };
  }

  const explanation = correction.reasons.join("\n");
  
  // Generate a practice exercise based on the correction
  const practice = generatePracticeFromCorrection(
    correction.original,
    correction.corrected,
    correction.reasons
  );

  return {
    explanation,
    examples: [],
    practice
  };
}

// ==============================
// PRACTICE GENERATOR
// ==============================

function generatePracticeFromCorrection(original, corrected, reasons) {
  // Parse the correction to find what was fixed
  const changedWords = [];
  const origWords = original.split(/\s+/);
  const corrWords = corrected.split(/\s+/);
  
  for (let i = 0; i < Math.min(origWords.length, corrWords.length); i++) {
    if (origWords[i] !== corrWords[i]) {
      changedWords.push({ original: origWords[i], corrected: corrWords[i] });
    }
  }

  if (changedWords.length > 0) {
    // Create a fill-in-the-blank exercise
    const blankSentence = corrected.replace(changedWords[0].corrected, "______");
    return {
      type: "fill",
      question: `Complete the sentence: "${blankSentence}"`,
      answer: changedWords[0].corrected,
      hint: `The correct form is "${changedWords[0].corrected}"`
    };
  }

  return {
    type: "translate",
    question: `Translate this sentence to Spanish: "${corrected}"`,
    answer: corrected
  };
}
