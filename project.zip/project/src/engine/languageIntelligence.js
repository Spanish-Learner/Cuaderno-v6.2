// src/engine/languageIntelligence.js
import { analyze, quickAnalyze, extractVocabulary, lookupWord } from "./languageEngine";
import { parseSentence } from "./parser";
import { translateSpanishToEnglish, translateEnglishToSpanish } from "./translator";
import { correctSentence } from "./grammar";
import { resolveConjugation } from "./conjugationResolver";

// ============================================================
// LANGUAGE INTELLIGENCE LAYER
// ============================================================

class LanguageIntelligence {
  constructor(dictionary = null) {
    this.dictionary = dictionary;
    this.cache = new Map();
    this.maxCacheSize = 100;
  }

  // ============================================================
  // MAIN ENTRY POINT
  // ============================================================

  analyze(sentence) {
    // Check cache first
    if (this.cache.has(sentence)) {
      return this.cache.get(sentence);
    }

    const analysis = analyze(sentence);
    const translation = this.translate(sentence);
    const correction = this.correct(sentence);

    const result = {
      analysis,
      translation,
      correction,
      original: sentence,
      timestamp: Date.now()
    };

    // Cache the result
    this.cache.set(sentence, result);
    if (this.cache.size > this.maxCacheSize) {
      // Remove oldest entry
      const firstKey = this.cache.keys().next().value;
      this.cache.delete(firstKey);
    }

    return result;
  }

  // ============================================================
  // TRANSLATION
  // ============================================================

  translate(sentence, direction = "es-en") {
    if (direction === "es-en") {
      return translateSpanishToEnglish(sentence, this.dictionary);
    } else {
      return translateEnglishToSpanish(sentence, this.dictionary);
    }
  }

  // ============================================================
  // CORRECTION
  // ============================================================

  correct(sentence) {
    return correctSentence(sentence);
  }

  // ============================================================
  // PARSING
  // ============================================================

  parse(sentence) {
    return parseSentence(sentence);
  }

  // ============================================================
  // WORD LOOKUP
  // ============================================================

  lookup(word) {
    // Check if it's a conjugated verb
    const conjugated = resolveConjugation(word);
    if (conjugated) {
      return {
        type: "verb",
        base: conjugated.base,
        tense: conjugated.tense,
        person: conjugated.person,
        regular: conjugated.regular
      };
    }

    // Check dictionary
    if (this.dictionary) {
      const entry = lookupWord(word, this.dictionary);
      if (entry) return entry;
    }

    return null;
  }

  // ============================================================
  // VOCABULARY EXTRACTION
  // ============================================================

  extractVocabulary(sentence) {
    return extractVocabulary(sentence);
  }

  // ============================================================
  // SENTENCE METADATA
  // ============================================================

  getMetadata(sentence) {
    const analysis = analyze(sentence);
    return {
      length: analysis.wordCount,
      hasVerb: analysis.hasVerb,
      hasSubject: analysis.hasSubject,
      isQuestion: analysis.isQuestion,
      tense: analysis.tense,
      entities: analysis.entities,
      complexity: analysis.wordCount > 10 ? "complex" : analysis.wordCount > 5 ? "medium" : "simple"
    };
  }

  // ============================================================
  // CACHE MANAGEMENT
  // ============================================================

  clearCache() {
    this.cache.clear();
  }

  getCacheStats() {
    return {
      size: this.cache.size,
      maxSize: this.maxCacheSize
    };
  }
}

// ============================================================
// SINGLETON INSTANCE
// ============================================================

let instance = null;

export function getLanguageIntelligence(dictionary = null) {
  if (!instance) {
    instance = new LanguageIntelligence(dictionary);
  }
  return instance;
}

export function resetLanguageIntelligence() {
  instance = null;
}