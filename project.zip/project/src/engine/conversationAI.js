// src/engine/conversationAI.js
import {
  generateResponse,
  generateCorrectionMessage,
  generateContinuationResponse
} from "./conversationGenerator";

// ============================================================
// SINGLETON ACCESSOR (used by the engine manifest)
// ============================================================

let conversationAIInstance = null;

export function getConversationAI() {
  if (!conversationAIInstance) {
    conversationAIInstance = {
      generateResponse,
      generateCorrectionMessage,
      generateContinuationResponse
    };
  }
  return conversationAIInstance;
}
