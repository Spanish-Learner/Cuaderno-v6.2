// src/engine/engineLifecycle.js

export const LIFECYCLE_STATE = {
  NEW: 'NEW',
  INITIALIZING: 'INITIALIZING',
  READY: 'READY',
  DISPOSING: 'DISPOSING',
  DISPOSED: 'DISPOSED'
};

export class EngineLifecycle {
  constructor() {
    this._state = LIFECYCLE_STATE.NEW;
    this._abortController = null;
    this._disposePromise = null;
  }

  getState() { return this._state; }
  isReady() { return this._state === LIFECYCLE_STATE.READY; }
  isDisposed() { return this._state === LIFECYCLE_STATE.DISPOSED; }

  async initialize(context, signal) {
    if (this._state !== LIFECYCLE_STATE.NEW) {
      throw new Error(`Cannot initialize engine from state: ${this._state}`);
    }
    this._state = LIFECYCLE_STATE.INITIALIZING;
    this._abortController = new AbortController();

    try {
      await this._onInitialize(context, signal);
      this._state = LIFECYCLE_STATE.READY;
    } catch (error) {
      this._state = LIFECYCLE_STATE.DISPOSED;
      throw error;
    }
  }

  async dispose() {
    if (this._state === LIFECYCLE_STATE.DISPOSED) return;
    if (this._disposePromise) return this._disposePromise;

    this._disposePromise = (async () => {
      this._state = LIFECYCLE_STATE.DISPOSING;
      if (this._abortController) {
        this._abortController.abort(new Error('Engine disposed'));
      }
      await this._onDispose();
      this._state = LIFECYCLE_STATE.DISPOSED;
    })();

    return this._disposePromise;
  }

  async _onInitialize(context, signal) {
    throw new Error('EngineLifecycle._onInitialize() must be implemented.');
  }

  async _onDispose() {
    // Override to clean up resources
  }
}