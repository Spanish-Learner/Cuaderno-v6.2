// src/engine/databaseLoader.js
import { LANGUAGE_DATABASE } from "../data/languageDatabase";
import { buildConjugationIndex, DEFAULT_REGULAR_VERBS } from "./conjugationIndex";
import { IRREGULAR_VERB_LIST } from "../data/irregularConjugations";

// Build the complete language engine at startup
export function loadLanguageEngine() {
  console.log("🔄 Loading Spanish Language Database...");
  
  // 1. Load words
  const words = LANGUAGE_DATABASE.words;
  console.log(`✅ Loaded ${words.length} words`);
  
  // 2. Build conjugation index
  const regularVerbs = words
    .filter(w => w.type === "verb" && w.regular)
    .map(w => w.word);
  
  const conjugationIndex = buildConjugationIndex(regularVerbs, IRREGULAR_VERB_LIST);
  console.log(`✅ Built conjugation index with ${Object.keys(conjugationIndex).length} forms`);
  
  // 3. Return the complete engine
  return {
    words,
    conjugationIndex,
    categories: LANGUAGE_DATABASE.categories,
    cefrLevels: LANGUAGE_DATABASE.cefrLevels,
    lexicalFamilies: LANGUAGE_DATABASE.lexicalFamilies,
    
    // Helpers
    getWord: LANGUAGE_DATABASE.getWord,
    getWordsByCategory: LANGUAGE_DATABASE.getWordsByCategory,
    getWordsByLevel: LANGUAGE_DATABASE.getWordsByLevel,
    getLexicalFamily: LANGUAGE_DATABASE.getLexicalFamily,
    getRelatedWords: LANGUAGE_DATABASE.getRelatedWords,
    search: LANGUAGE_DATABASE.searchDatabase,
    
    // Conjugation
    resolveConjugation: (form) => conjugationIndex[form.toLowerCase()] || null,
    isConjugatedForm: (form) => !!conjugationIndex[form.toLowerCase()],
    
    // Stats
    stats: {
      totalWords: words.length,
      totalVerbs: words.filter(w => w.type === "verb").length,
      totalNouns: words.filter(w => w.type === "noun").length,
      totalAdjectives: words.filter(w => w.type === "adjective").length,
      totalExpressions: words.filter(w => w.type === "expression").length,
      totalConjugatedForms: Object.keys(conjugationIndex).length
    }
  };
}

// Singleton instance
let languageEngine = null;

export function getLanguageEngine() {
  if (!languageEngine) {
    languageEngine = loadLanguageEngine();
  }
  return languageEngine;
}

// Reset (for testing)
export function resetLanguageEngine() {
  languageEngine = null;
}