// src/engine/engineStatus.js

export const ENGINE_STATUS = {
  NOT_STARTED: 'NOT_STARTED',
  LOADING: 'LOADING',
  READY: 'READY',
  FAILED: 'FAILED',
  DISABLED: 'DISABLED',
  LAZY: 'LAZY'
};

export class EngineStatus {
  constructor(name) {
    this._name = name;
    this._status = ENGINE_STATUS.NOT_STARTED;
    this._error = null;
    this._lastTransition = Date.now();
  }

  markLoading() { this._status = ENGINE_STATUS.LOADING; this._lastTransition = Date.now(); }
  markReady() { this._status = ENGINE_STATUS.READY; this._lastTransition = Date.now(); }
  markFailed(error) { this._status = ENGINE_STATUS.FAILED; this._error = error; this._lastTransition = Date.now(); }
  markDisabled(reason) { this._status = ENGINE_STATUS.DISABLED; this._error = reason; this._lastTransition = Date.now(); }
  markLazy() { this._status = ENGINE_STATUS.LAZY; this._lastTransition = Date.now(); }

  getStatus() { return this._status; }
  getError() { return this._error; }

  isReady() { return this._status === ENGINE_STATUS.READY; }
  isFailed() { return this._status === ENGINE_STATUS.FAILED; }
  isDisabled() { return this._status === ENGINE_STATUS.DISABLED; }
  isLazy() { return this._status === ENGINE_STATUS.LAZY; }

  snapshot() {
    return Object.freeze({
      name: this._name,
      status: this._status,
      error: this._error
    });
  }
}