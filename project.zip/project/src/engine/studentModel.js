// src/engine/studentModel.js
import { loadState, saveState } from './storage';
import { createInitialState } from '../state/initialState';

export function getStudentStats(student) {
  if (!student) {
    return {
      level: 'A1',
      xp: 0,
      streak: 0,
      accuracy: 0,
      knownWords: 0,
      weakWords: 0,
      totalMistakes: 0,
      sessionsCompleted: 0,
      mistakes: {}
    };
  }

  const totalMistakes = Object.values(student.mistakes || {}).reduce(
    (sum, category) => sum + Object.values(category || {}).reduce((a, b) => a + b, 0),
    0
  );

  return {
    level: student.level || 'A1',
    xp: student.xp || 0,
    streak: student.streak || 0,
    accuracy: student.accuracy || 0,
    knownWords: student.knownWords?.length || 0,
    weakWords: student.weakWords?.length || 0,
    totalMistakes,
    sessionsCompleted: student.sessionsCompleted || 0,
    mistakes: student.mistakes || {}
  };
}

// ============================================================
// LOAD / SAVE
// ============================================================

export function loadStudent() {
  const state = loadState();
  return state.student;
}

export function saveStudent(student) {
  const state = loadState();
  saveState({ ...state, student });
  return student;
}

export function updateStudent(student, updates) {
  if (!student) return student;
  const updated = { ...student, ...updates };
  saveStudent(updated);
  return updated;
}

// ============================================================
// VOCABULARY TRACKING
// ============================================================

export function isWordKnown(student, word) {
  return !!(student?.knownWords || []).includes(word);
}

export function markWordKnown(student, word) {
  if (!student) return student;
  const knownWords = student.knownWords || [];
  if (knownWords.includes(word)) return student;
  const weakWords = (student.weakWords || []).filter((w) => w !== word);
  return { ...student, knownWords: [...knownWords, word], weakWords };
}

export function markWordWeak(student, word) {
  if (!student) return student;
  const weakWords = student.weakWords || [];
  if (weakWords.includes(word)) return student;
  return { ...student, weakWords: [...weakWords, word] };
}

// ============================================================
// MISTAKES
// ============================================================

export function recordMistake(student, category, key) {
  if (!student) return student;
  const mistakes = student.mistakes || {};
  const categoryMistakes = mistakes[category] || {};
  return {
    ...student,
    mistakes: {
      ...mistakes,
      [category]: {
        ...categoryMistakes,
        [key]: (categoryMistakes[key] || 0) + 1
      }
    }
  };
}

// ============================================================
// ACCURACY
// ============================================================

export function updateAccuracy(student, wasCorrect) {
  if (!student) return student;
  const totalAttempts = (student.totalAttempts || 0) + 1;
  const totalCorrect = (student.totalCorrect || 0) + (wasCorrect ? 1 : 0);
  const accuracy = Math.round((totalCorrect / totalAttempts) * 100);
  return { ...student, totalAttempts, totalCorrect, accuracy };
}

// ============================================================
// XP / LEVELING
// ============================================================

const LEVEL_THRESHOLDS = [
  { level: 'A1', minXP: 0 },
  { level: 'A2', minXP: 200 },
  { level: 'B1', minXP: 600 },
  { level: 'B2', minXP: 1200 }
];

export function checkLevelUp(student) {
  if (!student) return student;
  let newLevel = student.level || 'A1';
  for (const { level, minXP } of LEVEL_THRESHOLDS) {
    if ((student.xp || 0) >= minXP) newLevel = level;
  }
  if (newLevel === student.level) return student;
  return { ...student, level: newLevel };
}

export function addXP(student, amount) {
  if (!student) return student;
  const withXP = { ...student, xp: (student.xp || 0) + amount };
  return checkLevelUp(withXP);
}

// ============================================================
// RESET
// ============================================================

export function resetStudent() {
  return createInitialState().student;
}
