// src/engine/stateMigrator.js
import { APP_VERSION } from '../constants';
import { compareVersions } from '../utils/version';

const MIGRATIONS = {
  '6.0.0': (state) => {
    console.log('Running migration: 6.0.0 -> 6.0.1');
    if (state.student && state.student.wordsLearned) {
      state.student.knownWords = state.student.wordsLearned;
      delete state.student.wordsLearned;
    }
    state.version = '6.0.1';
    return state;
  },
  '6.0.1': (state) => {
    console.log('Running migration: 6.0.1 -> 6.0.2');
    if (!state.student.achievements) {
      state.student.achievements = [];
    }
    state.version = '6.0.2';
    return state;
  }
};

export class StateMigrator {
  constructor() {
    this.migrations = MIGRATIONS;
    this.targetVersion = APP_VERSION;
  }

  migrate(state) {
    if (!state || typeof state !== 'object') return state;

    const currentVersion = state.version || '0.0.0';

    if (compareVersions(currentVersion, this.targetVersion) === 0) {
      return state;
    }

    console.log(`Migrating state from v${currentVersion} to v${this.targetVersion}`);

    let migratedState = state;
    let version = currentVersion;

    while (compareVersions(version, this.targetVersion) !== 0) {
      if (compareVersions(version, this.targetVersion) > 0) {
        throw new Error(
          `MigrationError: Current version (v${version}) is newer than target (v${this.targetVersion}).`
        );
      }

      const migration = this.migrations[version];
      if (!migration) {
        throw new Error(
          `MigrationError: No migration path from v${version} to v${this.targetVersion}.`
        );
      }

      try {
        migratedState = migration(migratedState);
        version = migratedState.version;
      } catch (error) {
        throw new Error(`MigrationError: Failed to migrate from v${version}.`);
      }
    }

    migratedState.version = this.targetVersion;
    return migratedState;
  }

  needsMigration(state) {
    return state && compareVersions(state.version, this.targetVersion) !== 0;
  }
}

let instance = null;
export function getStateMigrator() {
  if (!instance) instance = new StateMigrator();
  return instance;
}