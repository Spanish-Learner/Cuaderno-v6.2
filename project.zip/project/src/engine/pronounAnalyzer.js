// src/engine/pronounAnalyzer.js

// ============================================================
// PRONOUN TYPES
// ============================================================

export const pronouns = {
  subject: ["yo", "tú", "él", "ella", "usted", "nosotros", "nosotras", "vosotros", "vosotras", "ellos", "ellas", "ustedes"],
  direct_object: ["me", "te", "lo", "la", "nos", "os", "los", "las"],
  indirect_object: ["me", "te", "le", "nos", "os", "les"],
  reflexive: ["me", "te", "se", "nos", "os"],
  prepositional: ["mí", "ti", "él", "ella", "usted", "nosotros", "nosotras", "vosotros", "vosotras", "ellos", "ellas", "ustedes"]
};

// ============================================================
// PRONOUN ANALYSIS
// ============================================================

export function analyzePronoun(word) {
  const lower = word.toLowerCase();
  
  for (const [type, list] of Object.entries(pronouns)) {
    if (list.includes(lower)) {
      return { type, pronoun: lower };
    }
  }
  
  return null;
}

// ============================================================
// PRONOUN CHECKS
// ============================================================

export function isPronoun(word) {
  return analyzePronoun(word) !== null;
}

export function getPronounType(word) {
  const analysis = analyzePronoun(word);
  return analysis ? analysis.type : null;
}

export function isSubjectPronoun(word) {
  return pronouns.subject.includes(word.toLowerCase());
}

export function isObjectPronoun(word) {
  return pronouns.direct_object.includes(word.toLowerCase()) || 
         pronouns.indirect_object.includes(word.toLowerCase());
}

export function isReflexivePronoun(word) {
  return pronouns.reflexive.includes(word.toLowerCase());
}

// ============================================================
// PRONOUN USAGE CHECK
// ============================================================

export function checkPronounUsage(pronoun, context) {
  const analysis = analyzePronoun(pronoun);
  if (!analysis) return null;
  
  // Check if pronoun matches its position in sentence
  // Subject pronouns usually appear before the verb
  const issues = [];
  
  if (analysis.type === "subject") {
    if (context.indexOf(pronoun) > context.indexOf("verb")) {
      issues.push({
        error: true,
        reason: `"${pronoun}" is a subject pronoun but appears after the verb.`,
        suggestion: `Move "${pronoun}" before the verb.`
      });
    }
  }
  
  return issues.length > 0 ? issues : null;
}

// ============================================================
// PRONOUN TRANSLATION
// ============================================================

export function translatePronoun(pronoun, type = "subject") {
  const translations = {
    subject: {
      "yo": "I",
      "tú": "you",
      "él": "he",
      "ella": "she",
      "usted": "you",
      "nosotros": "we",
      "nosotras": "we",
      "vosotros": "you all",
      "vosotras": "you all",
      "ellos": "they",
      "ellas": "they",
      "ustedes": "you all"
    },
    object: {
      "me": "me",
      "te": "you",
      "lo": "him/it",
      "la": "her/it",
      "nos": "us",
      "os": "you all",
      "los": "them",
      "las": "them",
      "le": "to him/her"
    },
    reflexive: {
      "me": "myself",
      "te": "yourself",
      "se": "himself/herself/itself",
      "nos": "ourselves",
      "os": "yourselves"
    }
  };

  const lower = pronoun.toLowerCase();
  const map = translations[type] || translations.subject;
  return map[lower] || pronoun;
}