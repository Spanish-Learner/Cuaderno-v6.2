// src/engine/reasoningEngine.js
import { parseSentence } from "./parser";
import { resolveConjugation, getVerbForms } from "./conjugationIndex";
import { getLanguageEngine } from "./databaseLoader";
import { getLearningGraphEngine } from "./learningGraphEngine";

export class ReasoningEngine {
  constructor() {
    this.languageEngine = getLanguageEngine();
    this.graphEngine = getLearningGraphEngine();
    this.verbCache = new Map();
  }

  // ============================================================
  // ANALYZE SENTENCE STRUCTURE
  // ============================================================

  analyzeSentence(sentence) {
    const parse = parseSentence(sentence);
    const { structure } = parse;
    
    // Build a detailed structural analysis
    const analysis = {
      original: sentence,
      words: sentence.split(/\s+/),
      subject: this.analyzeSubject(structure.subject),
      verb: this.analyzeVerb(structure.verb),
      objects: structure.objects.map(o => o.word),
      tense: structure.verb?.tense || "unknown",
      timeMarker: structure.timeMarker || null,
      isQuestion: structure.question || false,
      isExclamation: structure.exclamation || false,
      structure: structure
    };

    // Add reasoning about the sentence
    analysis.reasoning = this.generateReasoning(analysis);
    
    return analysis;
  }

  // ============================================================
  // ANALYZE SUBJECT
  // ============================================================

  analyzeSubject(subject) {
    if (!subject) return null;
    
    const subjectData = {
      word: subject.word,
      type: subject.type || "pronoun",
      person: null,
      number: "singular"
    };

    // Map pronouns to person/number
    const pronounMap = {
      "yo": { person: 1, number: "singular" },
      "tú": { person: 2, number: "singular" },
      "él": { person: 3, number: "singular" },
      "ella": { person: 3, number: "singular" },
      "usted": { person: 3, number: "singular" },
      "nosotros": { person: 1, number: "plural" },
      "nosotras": { person: 1, number: "plural" },
      "vosotros": { person: 2, number: "plural" },
      "vosotras": { person: 2, number: "plural" },
      "ellos": { person: 3, number: "plural" },
      "ellas": { person: 3, number: "plural" },
      "ustedes": { person: 3, number: "plural" }
    };

    if (pronounMap[subject.word]) {
      subjectData.person = pronounMap[subject.word].person;
      subjectData.number = pronounMap[subject.word].number;
    }

    return subjectData;
  }

  // ============================================================
  // ANALYZE VERB
  // ============================================================

  analyzeVerb(verb) {
    if (!verb) return null;
    
    const verbData = {
      infinitive: verb.word,
      form: verb.form,
      tense: verb.tense || "present",
      person: null,
      number: "singular",
      regular: true,
      isIrregular: false
    };

    // Resolve the conjugated form
    const resolved = resolveConjugation(verb.form);
    if (resolved) {
      verbData.infinitive = resolved.base;
      verbData.tense = resolved.tense;
      verbData.regular = resolved.regular;
      verbData.isIrregular = !resolved.regular;
      
      // Map person from the resolved data
      if (resolved.person) {
        const personMap = {
          1: { person: 1, number: "singular" },
          2: { person: 2, number: "singular" },
          3: { person: 3, number: "singular" },
          4: { person: 1, number: "plural" },
          5: { person: 2, number: "plural" },
          6: { person: 3, number: "plural" }
        };
        if (personMap[resolved.person]) {
          verbData.person = personMap[resolved.person].person;
          verbData.number = personMap[resolved.person].number;
        }
      }
    }

    return verbData;
  }

  // ============================================================
  // GENERATE REASONING
  // ============================================================

  generateReasoning(analysis) {
    const reasoning = {
      tense: this.reasonTense(analysis),
      subjectVerbAgreement: this.reasonSubjectVerbAgreement(analysis),
      timeContext: this.reasonTimeContext(analysis),
      corrections: []
    };

    // Check for errors
    if (analysis.subject && analysis.verb) {
      const agreement = this.checkSubjectVerbAgreement(analysis.subject, analysis.verb);
      if (!agreement.valid) {
        reasoning.corrections.push({
          type: "subject_verb_agreement",
          original: `${analysis.subject.word} ${analysis.verb.form}`,
          suggested: agreement.suggested,
          explanation: agreement.explanation
        });
      }
    }

    // Check tense consistency
    if (analysis.timeMarker && analysis.tense) {
      const tenseCheck = this.checkTenseConsistency(analysis.timeMarker, analysis.tense);
      if (!tenseCheck.valid) {
        reasoning.corrections.push({
          type: "tense_consistency",
          original: `${analysis.timeMarker} + ${analysis.tense}`,
          suggested: tenseCheck.suggested,
          explanation: tenseCheck.explanation
        });
      }
    }

    return reasoning;
  }

  // ============================================================
  // REASON ABOUT TENSE
  // ============================================================

  reasonTense(analysis) {
    const tenseMap = {
      "present": "The action is happening now or is a general truth.",
      "preterite": "The action happened at a specific point in the past.",
      "imperfect": "The action was ongoing or habitual in the past.",
      "future": "The action will happen in the future.",
      "conditional": "The action would happen under certain conditions."
    };

    return {
      detected: analysis.tense,
      explanation: tenseMap[analysis.tense] || "Tense could not be determined.",
      confidence: analysis.tense !== "unknown" ? 0.9 : 0.1
    };
  }

  // ============================================================
  // REASON ABOUT SUBJECT-VERB AGREEMENT
  // ============================================================

  reasonSubjectVerbAgreement(analysis) {
    if (!analysis.subject || !analysis.verb) {
      return {
        hasAgreement: false,
        explanation: "Subject or verb not found."
      };
    }

    const subject = analysis.subject;
    const verb = analysis.verb;

    if (subject.person !== verb.person) {
      return {
        hasAgreement: false,
        explanation: `"${subject.word}" (${this.personToString(subject.person)}) does not match "${verb.form}" (${this.personToString(verb.person)}).`,
        expected: `Use the ${this.personToString(subject.person)} form of "${verb.infinitive}".`
      };
    }

    return {
      hasAgreement: true,
      explanation: `"${subject.word}" correctly agrees with "${verb.form}".`
    };
  }

  // ============================================================
  // REASON ABOUT TIME CONTEXT
  // ============================================================

  reasonTimeContext(analysis) {
    if (!analysis.timeMarker) {
      return {
        hasContext: false,
        explanation: "No time marker detected."
      };
    }

    const timeMap = {
      "ayer": "The action happened yesterday.",
      "hoy": "The action is happening today.",
      "mañana": "The action will happen tomorrow.",
      "ahora": "The action is happening right now.",
      "luego": "The action will happen later.",
      "después": "The action will happen afterwards.",
      "antes": "The action happened before.",
      "siempre": "The action always happens.",
      "nunca": "The action never happens."
    };

    return {
      hasContext: true,
      marker: analysis.timeMarker,
      explanation: timeMap[analysis.timeMarker] || `Time marker "${analysis.timeMarker}" detected.`,
      tenseExpected: this.inferTenseFromTime(analysis.timeMarker)
    };
  }

  // ============================================================
  // CHECK SUBJECT-VERB AGREEMENT
  // ============================================================

  checkSubjectVerbAgreement(subject, verb) {
    if (!subject || !verb) {
      return { valid: true };
    }

    // If we have person data, check it
    if (subject.person !== null && verb.person !== null) {
      if (subject.person !== verb.person) {
        // Generate the correct form
        const correctForm = this.getCorrectVerbForm(verb.infinitive, verb.tense, subject.person);
        
        return {
          valid: false,
          suggested: correctForm,
          explanation: `"${subject.word}" is ${this.personToString(subject.person)} person ${subject.number}, but "${verb.form}" is ${this.personToString(verb.person)} person ${verb.number}.`
        };
      }
    }

    return { valid: true };
  }

  // ============================================================
  // CHECK TENSE CONSISTENCY
  // ============================================================

  checkTenseConsistency(timeMarker, tense) {
    const timeToTense = {
      "ayer": "preterite",
      "hoy": "present",
      "mañana": "future",
      "ahora": "present",
      "luego": "future",
      "después": "future",
      "antes": "preterite",
      "siempre": "present"
    };

    const expected = timeToTense[timeMarker];
    if (expected && expected !== tense) {
      return {
        valid: false,
        suggested: expected,
        explanation: `"${timeMarker}" suggests ${expected} tense, but "${tense}" tense was used.`
      };
    }

    return { valid: true };
  }

  // ============================================================
  // HELPERS
  // ============================================================

  personToString(person) {
    const map = {
      1: "first",
      2: "second",
      3: "third"
    };
    return map[person] || "unknown";
  }

  getCorrectVerbForm(infinitive, tense, person) {
    const forms = getVerbForms(infinitive, tense);
    if (!forms) return "";
    
    const personIndex = {
      1: 0,  // yo
      2: 1,  // tú
      3: 2,  // él/ella/usted
      4: 3,  // nosotros
      5: 4,  // vosotros
      6: 5   // ellos/ellas/ustedes
    };
    
    const index = personIndex[person];
    return index !== undefined && forms[index] ? forms[index] : "";
  }

  inferTenseFromTime(timeMarker) {
    const map = {
      "ayer": "preterite",
      "hoy": "present",
      "mañana": "future",
      "ahora": "present",
      "luego": "future",
      "después": "future",
      "antes": "preterite",
      "siempre": "present"
    };
    return map[timeMarker] || "unknown";
  }

  // ============================================================
  // GENERATE FULL CORRECTION WITH REASONING
  // ============================================================

  generateFullCorrection(sentence) {
    const analysis = this.analyzeSentence(sentence);
    const reasoning = analysis.reasoning;
    
    let corrected = sentence;
    let explanations = [];

    // Apply corrections based on reasoning
    if (reasoning.corrections.length > 0) {
      for (const correction of reasoning.corrections) {
        if (correction.type === "subject_verb_agreement") {
          corrected = corrected.replace(
            correction.original.split(" ")[1] || "",
            correction.suggested
          );
          explanations.push({
            original: correction.original,
            suggested: `${correction.original.split(" ")[0]} ${correction.suggested}`,
            explanation: correction.explanation
          });
        }
        
        if (correction.type === "tense_consistency") {
          // More complex: need to change the verb to the correct tense
          // This is a simplified version
          explanations.push({
            original: correction.original,
            suggested: correction.suggested,
            explanation: correction.explanation
          });
        }
      }
    }

    return {
      original: sentence,
      corrected,
      analysis,
      reasoning,
      explanations: explanations.length > 0 ? explanations : [
        { explanation: "No corrections needed. ¡Perfecto!" }
      ]
    };
  }

  // ============================================================
  // ANSWER WHY QUESTIONS
  // ============================================================

  answerWhy(original, corrected, reasons) {
    if (!reasons || reasons.length === 0) {
      return {
        question: "Why was this corrected?",
        answer: "No correction was needed — the sentence was already correct.",
        examples: []
      };
    }

    const analysis = this.analyzeSentence(original);
    
    return {
      question: "Why was this corrected?",
      answer: reasons.join("\n"),
      analysis: analysis,
      examples: this.generateExampleSentences(analysis)
    };
  }

  generateExampleSentences(analysis) {
    const examples = [];
    
    if (analysis.verb) {
      const verb = analysis.verb.infinitive;
      const tense = analysis.verb.tense;
      
      // Generate example sentences using the same verb and tense
      const subjects = ["yo", "tú", "él", "nosotros", "ellos"];
      const objects = ["una pizza", "un libro", "al parque", "en casa", "con amigos"];
      
      for (let i = 0; i < 3; i++) {
        const subject = subjects[i % subjects.length];
        const object = objects[i % objects.length];
        const form = this.getCorrectVerbForm(verb, tense, i % 5 + 1);
        
        if (form) {
          examples.push({
            spanish: `${subject.charAt(0).toUpperCase() + subject.slice(1)} ${form} ${object}.`,
            english: `${subject} ${this.getEnglishVerb(verb, tense)} ${object}.`
          });
        }
      }
    }
    
    return examples;
  }

  getEnglishVerb(spanishVerb, tense) {
    const verbMap = {
      "comer": "eat",
      "hablar": "speak",
      "ir": "go",
      "ser": "be",
      "estar": "be",
      "tener": "have",
      "hacer": "do",
      "decir": "say",
      "poder": "can",
      "querer": "want",
      "saber": "know",
      "vivir": "live",
      "trabajar": "work",
      "estudiar": "study"
    };
    
    const base = verbMap[spanishVerb] || spanishVerb;
    const tenseMap = {
      "present": base,
      "preterite": `${base}d`,
      "imperfect": `was ${base}ing`,
      "future": `will ${base}`
    };
    
    return tenseMap[tense] || base;
  }
}

// Singleton
let reasoningEngine = null;

export function getReasoningEngine() {
  if (!reasoningEngine) {
    reasoningEngine = new ReasoningEngine();
  }
  return reasoningEngine;
}