// src/engine/conversationGenerator.js
import { getTutorEngine } from "./tutorEngine";
import { getLanguageEngine } from "./databaseLoader";
import { analyze } from "./languageEngine";

// ============================================================
// RESPONSE TEMPLATES BY LEVEL
// ============================================================

const RESPONSES = {
  A1: {
    greetings: [
      "¡Hola! ¿Cómo estás?",
      "¡Buenos días! ¿Qué tal?",
      "¡Qué bien verte! ¿Cómo estás hoy?"
    ],
    followUps: [
      "¡Qué bien! Cuéntame más.",
      "¡Interesante! ¿Y qué más?",
      "¡Claro! Sigue así.",
      "¡Perfecto! ¿Algo más?"
    ],
    corrections: [
      "Pequeña corrección: ",
      "Una cosita: ",
      "Recuerda: "
    ],
    encouragements: [
      "¡Muy bien!",
      "¡Excelente!",
      "¡Genial!",
      "¡Perfecto!"
    ]
  },
  A2: {
    greetings: [
      "¡Hola! ¿Cómo ha sido tu día?",
      "¡Buenas tardes! ¿Qué has hecho hoy?",
      "¡Qué alegría verte! ¿Cómo estás?"
    ],
    followUps: [
      "¡Qué interesante! Cuéntame más detalles.",
      "¿De verdad? No sabía eso.",
      "¡Qué bien! ¿Y qué opinas de eso?",
      "Muy bien. ¿Puedes darme un ejemplo?"
    ],
    corrections: [
      "Una pequeña corrección: ",
      "Aquí hay un detalle: ",
      "Recuerda que: "
    ],
    encouragements: [
      "¡Muy bien!",
      "¡Excelente progreso!",
      "¡Sigue así!",
      "¡Perfecto!"
    ]
  },
  B1: {
    greetings: [
      "¡Hola! ¿Qué tal todo?",
      "¡Buenas! ¿Cómo van las cosas?",
      "¡Qué gusto verte! ¿Cómo estás?"
    ],
    followUps: [
      "¡Qué fascinante! ¿Cómo fue esa experiencia?",
      "Entiendo perfectamente. ¿Y qué piensas de eso?",
      "¡Qué interesante! ¿Desde cuándo te interesa eso?",
      "Muy bien. ¿Puedes contarme más sobre eso?"
    ],
    corrections: [
      "Pequeña observación: ",
      "Una nota: ",
      "Algo para tener en cuenta: "
    ],
    encouragements: [
      "¡Excelente!",
      "¡Muy bien pensado!",
      "¡Qué buena respuesta!",
      "¡Perfecto!"
    ]
  },
  B2: {
    greetings: [
      "¡Hola! ¿Qué tal va todo?",
      "¡Buenas! ¿Cómo llevas el día?",
      "¡Qué gusto verte! ¿Cómo estás?"
    ],
    followUps: [
      "¡Qué perspectiva tan interesante! ¿Qué te llevó a pensar así?",
      "Eso es algo que mucha gente no considera. ¿Cómo llegaste a esa conclusión?",
      "¡Qué fascinante! Me encantaría saber más sobre ese tema.",
      "Muy bien. ¿Has tenido experiencias similares antes?"
    ],
    corrections: [
      "Observación: ",
      "Un detalle importante: ",
      "Ten en cuenta que: "
    ],
    encouragements: [
      "¡Excelente!",
      "¡Muy buena respuesta!",
      "¡Qué bien!",
      "¡Perfecto!"
    ]
  }
};

// ============================================================
// RESPONSE GENERATOR
// ============================================================

export function generateResponse(input, context = null) {
  const tutorEngine = getTutorEngine();
  const student = tutorEngine.student;
  const level = student.level || "A1";
  
  // Analyze the input
  const analysis = analyze(input);
  
  // Check if it's a question
  if (analysis.isQuestion) {
    return generateQuestionResponse(input, level);
  }
  
  // Check for named entities
  const entities = extractEntities(analysis);
  if (entities.name) {
    return generatePersonalizedResponse(entities, level);
  }
  
  // Check for topic continuity
  if (context && context.lastTopic) {
    const topicResponse = generateTopicResponse(context.lastTopic, level);
    if (topicResponse) return topicResponse;
  }
  
  // Default: level-appropriate follow-up
  return getRandomResponse(level, "followUps");
}

// ============================================================
// QUESTION RESPONSE
// ============================================================

function generateQuestionResponse(input, level) {
  const responses = RESPONSES[level] || RESPONSES.A1;
  
  // Simple question detection
  if (input.includes("cómo") || input.includes("qué")) {
    return `${getRandomResponse(level, "greetings")} ${getRandomResponse(level, "followUps")}`;
  }
  
  return getRandomResponse(level, "followUps");
}

// ============================================================
// ENTITY EXTRACTION
// ============================================================

function extractEntities(analysis) {
  const entities = {
    name: null,
    age: null,
    food: null,
    sport: null,
    color: null
  };
  
  // Extract name
  const nameMatch = analysis.original.match(/me llamo\s+(\w+)/i);
  if (nameMatch) entities.name = nameMatch[1];
  
  // Extract age
  const ageMatch = analysis.original.match(/tengo\s+(\d+)\s+años/i);
  if (ageMatch) entities.age = parseInt(ageMatch[1]);
  
  // Extract food
  if (analysis.entities?.foods?.length > 0) {
    entities.food = analysis.entities.foods[0];
  }
  
  // Extract sport
  if (analysis.entities?.sports?.length > 0) {
    entities.sport = analysis.entities.sports[0];
  }
  
  // Extract color
  if (analysis.entities?.colors?.length > 0) {
    entities.color = analysis.entities.colors[0];
  }
  
  return entities;
}

// ============================================================
// PERSONALIZED RESPONSE
// ============================================================

function generatePersonalizedResponse(entities, level) {
  if (entities.name) {
    return `¡Hola, ${entities.name}! ¿Cómo estás hoy?`;
  }
  if (entities.food) {
    return `¡Qué rico! ¿Te gusta cocinar ${entities.food}?`;
  }
  if (entities.sport) {
    return `¡Qué bien! ¿Juegas al ${entities.sport} frecuentemente?`;
  }
  return getRandomResponse(level, "followUps");
}

// ============================================================
// TOPIC RESPONSE
// ============================================================

function generateTopicResponse(topic, level) {
  const topicResponses = {
    food: [
      "¿Cuál es tu comida favorita?",
      "¿Te gusta cocinar?",
      "¿Qué comiste hoy?"
    ],
    travel: [
      "¿Has viajado a algún país interesante?",
      "¿Cuál es tu ciudad favorita?",
      "¿Te gusta viajar?"
    ],
    family: [
      "¿Tienes hermanos?",
      "¿Cómo es tu familia?",
      "¿Vives con tu familia?"
    ],
    sports: [
      "¿Practicas algún deporte?",
      "¿Cuál es tu deporte favorito?",
      "¿Viste el partido ayer?"
    ],
    school: [
      "¿Qué estudias?",
      "¿Cómo va tu curso?",
      "¿Te gusta aprender español?"
    ]
  };
  
  const responses = topicResponses[topic];
  if (responses) {
    return responses[Math.floor(Math.random() * responses.length)];
  }
  
  return null;
}

// ============================================================
// UTILITY: GET RANDOM RESPONSE
// ============================================================

function getRandomResponse(level, category) {
  const levelResponses = RESPONSES[level] || RESPONSES.A1;
  const responses = levelResponses[category];
  if (!responses || responses.length === 0) return "Cuéntame más.";
  
  return responses[Math.floor(Math.random() * responses.length)];
}

// ============================================================
// CORRECTION MESSAGE
// ============================================================

export function generateCorrectionMessage(original, corrected, reasons) {
  const level = getTutorEngine().student.level || "A1";
  const prefix = getRandomResponse(level, "corrections");
  
  let message = `${prefix}"${original}" → "${corrected}"`;
  
  if (reasons && reasons.length > 0) {
    message += `\n${reasons.join("\n")}`;
  }
  
  const encouragement = getRandomResponse(level, "encouragements");
  message += `\n${encouragement} ¡Sigue practicando!`;
  
  return message;
}

// ============================================================
// CONVERSATION CONTINUITY
// ============================================================

export function generateContinuationResponse(context) {
  if (!context || !context.history || context.history.length === 0) {
    return getRandomResponse("A1", "greetings");
  }
  
  const lastMessage = context.history[context.history.length - 1];
  
  // If the last message was from the user, respond to it
  if (lastMessage && lastMessage.user) {
    return generateResponse(lastMessage.user, context);
  }
  
  // Otherwise, continue the conversation naturally
  return getRandomResponse("A1", "followUps");
}