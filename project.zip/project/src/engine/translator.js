// src/engine/translator.js
import { resolveConjugation } from "./conjugationResolver";
import { parseSentence, generateEnglishFromParse } from "./sentenceParser";

// ============================================================
// MULTI-WORD PHRASES
// ============================================================

const multiWordPhrases = {
  "buenos días": "good morning",
  "buenas tardes": "good afternoon",
  "buenas noches": "good evening",
  "por favor": "please",
  "muchas gracias": "thank you very much",
  "de nada": "you're welcome",
  "lo siento": "I'm sorry",
  "hasta luego": "see you later",
  "me gusta": "I like",
  "te quiero": "I love you",
  "cómo estás": "how are you",
  "qué tal": "how's it going"
};

export function buildPhraseMap(dictionary) {
  const map = {};
  Object.entries(multiWordPhrases).forEach(([k, v]) => {
    map[k] = v;
  });
  if (dictionary) {
    dictionary.forEach(word => {
      if (word.es) {
        map[word.es.toLowerCase()] = word.en;
      }
    });
  }
  return map;
}

export function tokenize(text) {
  return text
    .toLowerCase()
    .replace(/[.,!?]/g, "")
    .split(/\s+/)
    .filter(Boolean);
}

// ============================================================
// SPANISH → ENGLISH
// ============================================================

export function translateSpanishToEnglish(text, dictionary) {
  // First try to parse the sentence
  const parse = parseSentence(text);

  // If we have a verb, try to generate a natural translation
  if (parse.verb) {
    const english = generateEnglishFromParse(parse);
    if (english) return english;
  }

  // Fallback: phrase matching
  const phraseMap = buildPhraseMap(dictionary);
  let result = text.toLowerCase();

  // Check for multi-word phrases
  for (const [phrase, translation] of Object.entries(phraseMap)) {
    if (phrase.includes(" ")) {
      result = result.replaceAll(phrase, translation);
    }
  }

  // Word-by-word with conjugation resolution
  const words = tokenize(result);
  const translated = words.map(word => {
    // Check if it's a conjugated verb
    const resolved = resolveConjugation(word);
    if (resolved) return resolved.base;
    
    // Check dictionary
    if (dictionary) {
      const entry = dictionary.find(item =>
        item.es && item.es.toLowerCase() === word
      );
      if (entry) return entry.en;
    }
    
    // Return word if not found
    return `[${word}]`;
  });

  return translated.join(" ");
}

// ============================================================
// ENGLISH → SPANISH
// ============================================================

export function translateEnglishToSpanish(text, dictionary) {
  const words = text
    .toLowerCase()
    .replace(/[.,!?]/g, "")
    .split(/\s+/);

  return words
    .map(word => {
      if (dictionary) {
        const entry = dictionary.find(item =>
          item.en && item.en.toLowerCase() === word
        );
        if (entry) return entry.es;
      }
      return `[${word}]`;
    })
    .join(" ");
}

// ============================================================
// LEGACY SUPPORT
// ============================================================

export function translateSentence(sentence, dictionary) {
  return translateSpanishToEnglish(sentence, dictionary);
}

export function translateEnglish(sentence, dictionary) {
  return translateEnglishToSpanish(sentence, dictionary);
}
// ============================================================
// SINGLETON ACCESSOR (used by the engine manifest)
// ============================================================

let translatorInstance = null;

export function getTranslator() {
  if (!translatorInstance) {
    translatorInstance = {
      buildPhraseMap,
      tokenize,
      translateSpanishToEnglish,
      translateEnglishToSpanish,
      translateSentence,
      translateEnglish
    };
  }
  return translatorInstance;
}
