// src/engine/storage.js
import { createInitialState } from '../state/initialState';

const STORAGE_KEY = "cuaderno-spanish-v6";

export function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      const fresh = createInitialState();
      localStorage.setItem(STORAGE_KEY, JSON.stringify(fresh));
      return fresh;
    }
    const parsed = JSON.parse(raw);
    // Merge with defaults to fill missing fields
    const defaults = createInitialState();
    return mergeDeep(defaults, parsed);
  } catch (error) {
    console.error("Failed to load state, resetting to defaults:", error);
    const fresh = createInitialState();
    localStorage.setItem(STORAGE_KEY, JSON.stringify(fresh));
    return fresh;
  }
}

export function saveState(state) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch (error) {
    console.error("Failed to save state:", error);
  }
}

export function clearState() {
  localStorage.removeItem(STORAGE_KEY);
}

function mergeDeep(target, source) {
  const output = { ...target };
  for (const key in source) {
    if (source[key] && typeof source[key] === 'object' && !Array.isArray(source[key])) {
      output[key] = mergeDeep(target[key] || {}, source[key]);
    } else {
      output[key] = source[key];
    }
  }
  return output;
}