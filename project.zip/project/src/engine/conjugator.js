// src/engine/conjugator.js

// Regular verb endings for -ar, -er, -ir
const REGULAR_ENDINGS = {
  ar: {
    present: ["o", "as", "a", "amos", "áis", "an"],
    preterite: ["é", "aste", "ó", "amos", "asteis", "aron"],
    imperfect: ["aba", "abas", "aba", "ábamos", "abais", "aban"],
    future: ["aré", "arás", "ará", "aremos", "aréis", "arán"],
    conditional: ["aría", "arías", "aría", "aríamos", "aríais", "arían"],
    presentPerfect: ["ado"], // participle
    imperative: ["a", "ad"], // tú, vosotros
    presentSubjunctive: ["e", "es", "e", "emos", "éis", "en"]
  },
  er: {
    present: ["o", "es", "e", "emos", "éis", "en"],
    preterite: ["í", "iste", "ió", "imos", "isteis", "ieron"],
    imperfect: ["ía", "ías", "ía", "íamos", "íais", "ían"],
    future: ["eré", "erás", "erá", "eremos", "eréis", "erán"],
    conditional: ["ería", "erías", "ería", "eríamos", "eríais", "erían"],
    presentPerfect: ["ido"], // participle
    imperative: ["e", "ed"], // tú, vosotros
    presentSubjunctive: ["a", "as", "a", "amos", "áis", "an"]
  },
  ir: {
    present: ["o", "es", "e", "imos", "ís", "en"],
    preterite: ["í", "iste", "ió", "imos", "isteis", "ieron"],
    imperfect: ["ía", "ías", "ía", "íamos", "íais", "ían"],
    future: ["iré", "irás", "irá", "iremos", "iréis", "irán"],
    conditional: ["iría", "irías", "iría", "iríamos", "iríais", "irían"],
    presentPerfect: ["ido"], // participle
    imperative: ["e", "id"], // tú, vosotros
    presentSubjunctive: ["a", "as", "a", "amos", "áis", "an"]
  }
};

// Verb types
const VERB_TYPES = {
  ar: "ar",
  er: "er",
  ir: "ir"
};

// Get verb type from infinitive
export function getVerbType(infinitive) {
  const lastTwo = infinitive.slice(-2);
  if (lastTwo === "ar") return "ar";
  if (lastTwo === "er") return "er";
  if (lastTwo === "ir") return "ir";
  return null;
}

// Get stem from infinitive (remove -ar, -er, -ir)
export function getStem(infinitive) {
  return infinitive.slice(0, -2);
}

// Generate regular conjugations
export function generateRegularConjugations(infinitive) {
  const type = getVerbType(infinitive);
  if (!type) return null;
  
  const stem = getStem(infinitive);
  const endings = REGULAR_ENDINGS[type];
  const conjugations = {};

  for (const [tense, endingList] of Object.entries(endings)) {
    if (tense === "presentPerfect") {
      // Participle is just stem + ending
      conjugations[tense] = stem + endingList[0];
    } else if (Array.isArray(endingList)) {
      conjugations[tense] = endingList.map(end => stem + end);
    }
  }

  return conjugations;
}

// Conjugate a verb in a specific tense
export function conjugate(infinitive, tense) {
  const type = getVerbType(infinitive);
  if (!type) return [];
  
  const stem = getStem(infinitive);
  const endings = REGULAR_ENDINGS[type];
  const endingList = endings[tense];
  
  if (!endingList) return [];
  
  if (tense === "presentPerfect") {
    return [stem + endingList[0]];
  }
  
  return endingList.map(end => stem + end);
}

// Get all tenses for a verb
export function getAllTenses(infinitive) {
  const tenses = ["present", "preterite", "imperfect", "future", "conditional", "presentSubjunctive"];
  const result = {};
  
  for (const tense of tenses) {
    result[tense] = conjugate(infinitive, tense);
  }
  
  return result;
}

// Check if a verb is regular
export function isRegular(infinitive) {
  const IRREGULAR_VERBS = [
    "ir", "ser", "estar", "tener", "hacer", "decir", "venir",
    "poder", "poner", "querer", "saber", "haber", "traer",
    "salir", "dar", "ver", "caber", "oír", "valer", "caer"
  ];
  return !IRREGULAR_VERBS.includes(infinitive.toLowerCase());
}