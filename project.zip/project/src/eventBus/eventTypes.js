// src/eventBus/eventTypes.js

export const EVENTS = Object.freeze({
  ENGINE_STARTED: "engine.started",
  ENGINE_STOPPED: "engine.stopped",
  ENGINE_FAILED: "engine.failed",
  BOOT_STARTED: "boot.started",
  BOOT_COMPLETED: "boot.completed",
  STATE_CHANGED: "state.changed",
  LESSON_COMPLETED: "lesson.completed"
});