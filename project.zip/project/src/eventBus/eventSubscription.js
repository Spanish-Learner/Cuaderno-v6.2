// src/eventBus/eventSubscription.js

export class Subscription {
  constructor(bus, event, handler) {
    this._bus = bus;
    this._event = event;
    this._handler = handler;
    this._active = true;
  }

  unsubscribe() {
    if (!this._active) return;
    this._bus.unsubscribe(this._event, this._handler);
    this._active = false;
  }

  getEvent() { return this._event; }
  getHandler() { return this._handler; }

  _invalidate() {
    this._active = false;
  }

  isActive() {
    return this._active;
  }
}