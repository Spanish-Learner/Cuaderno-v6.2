// src/hooks/useTutor.js
import { useState, useEffect } from "react";
import { getTutorEngine } from "../engine/tutorEngine";
import { loadStudent, resetStudent, saveStudent } from "../engine/studentModel";

export default function useTutor() {
  const [engine, setEngine] = useState(null);
  const [student, setStudent] = useState(null);
  const [conversation, setConversation] = useState([]);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const tutor = getTutorEngine();
    setEngine(tutor);
    setStudent(loadStudent());
    setConversation(tutor.getConversationMemory());
    setStats(tutor.getStudentSnapshot());
    setLoading(false);
  }, []);

  const sendMessage = (message) => {
    if (!engine) return null;
    
    const result = engine.processInput(message);
    setStudent(result.student);
    setConversation(engine.getConversationMemory());
    setStats(result.student);
    
    return result;
  };

  const getPersonalizedLesson = () => {
    if (!engine) return null;
    return engine.generatePersonalizedLesson();
  };

  const getAchievements = () => {
    if (!student) return [];
    return student.achievements || [];
  };

  const getMistakeBreakdown = () => {
    if (!student) return {};
    return student.mistakes || {};
  };

  const resetProgress = () => {
    if (!engine) return;
    // Reset student progress back to defaults and persist it
    const newStudent = resetStudent();
    saveStudent(newStudent);

    setStudent(newStudent);
    setStats(newStudent);
    // Update engine's student
    engine.student = newStudent;
  };

  return {
    loading,
    student,
    conversation,
    stats,
    sendMessage,
    getPersonalizedLesson,
    getAchievements,
    getMistakeBreakdown,
    resetProgress,
    engine
  };
}