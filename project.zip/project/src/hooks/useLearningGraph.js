// src/hooks/useLearningGraph.js
import { useState, useEffect } from "react";
import { getLearningGraphEngine } from "../engine/learningGraphEngine";
import { loadStudent } from "../engine/studentModel";

export default function useLearningGraph() {
  const [engine, setEngine] = useState(null);
  const [student, setStudent] = useState(null);
  const [stats, setStats] = useState(null);
  const [recommendations, setRecommendations] = useState([]);

  useEffect(() => {
    const graphEngine = getLearningGraphEngine();
    setEngine(graphEngine);
    setStudent(loadStudent());
    setStats(graphEngine.getLearningStats());
    setRecommendations(graphEngine.getRecommendations());
  }, []);

  const markWordAsKnown = (word) => {
    if (!engine) return;
    const updated = engine.markWordAsKnown(word);
    setStudent(updated);
    setStats(engine.getLearningStats());
    setRecommendations(engine.getRecommendations());
  };

  const getRelatedWords = (word, depth = 2) => {
    if (!engine) return [];
    return engine.getRelatedWords(word, depth);
  };

  const getLearningPath = (targetWord) => {
    if (!engine) return [];
    return engine.buildLearningPath(targetWord);
  };

  const generateGraphLesson = (topic) => {
    if (!engine) return null;
    return engine.generateGraphLesson(topic);
  };

  const getGraphForWord = (word, depth = 2) => {
    if (!engine) return null;
    return engine.getGraphForWord(word, depth);
  };

  return {
    engine,
    student,
    stats,
    recommendations,
    markWordAsKnown,
    getRelatedWords,
    getLearningPath,
    generateGraphLesson,
    getGraphForWord
  };
}