// src/manifests/engineManifest.js
import { getLanguageEngine } from '../engine/databaseLoader';
import { getGrammarEngine } from '../engine/grammarEngine';
import { getTranslator } from '../engine/translator';
import { getTutorEngine } from '../engine/tutorEngine';
import { getLearningGraphEngine } from '../engine/learningGraphEngine';
import { getReasoningEngine } from '../engine/reasoningEngine';
import { getConversationAI } from '../engine/conversationAI';
import { getLessonGenerator } from '../engine/lessonGenerator';

// Create a manifest entry for each engine.
// The lifecycle class must implement the EngineLifecycle contract.
// Lazy engines are not initialized until first requested.

export const ENGINE_MANIFEST = Object.freeze([
  Object.freeze({
    id: 'languageDatabase',
    version: '1.0.0',
    apiVersion: '1.0.0',
    minimumAppVersion: '6.0.2',
    description: 'Central Spanish language database with CEFR-leveled vocabulary',
    category: 'data',
    priority: 0,
    tags: ['core', 'persistence'],
    capabilities: ['wordLookup', 'conjugationLookup'],
    lazy: false,
    dependencies: [],
    lifecycle: class {
      async initialize(context, signal) {
        const engine = getLanguageEngine();
        this._instance = engine;
        return engine;
      }
      async dispose() {
        this._instance = null;
      }
    }
  }),
  Object.freeze({
    id: 'dictionary',
    version: '1.0.0',
    apiVersion: '1.0.0',
    minimumAppVersion: '6.0.2',
    description: 'Word lookup and definition service',
    category: 'data',
    priority: 1,
    tags: ['core', 'lookup'],
    capabilities: ['wordDefinition'],
    lazy: false,
    dependencies: ['languageDatabase'],
    lifecycle: class {
      async initialize(context, signal) {
        const db = await context.registry?.getEngine?.('languageDatabase');
        this._instance = db?.getWord?.bind(db);
        return this._instance;
      }
      async dispose() {
        this._instance = null;
      }
    }
  }),
  Object.freeze({
    id: 'conjugation',
    version: '1.0.0',
    apiVersion: '1.0.0',
    minimumAppVersion: '6.0.2',
    description: 'Verb conjugation engine with irregular form support',
    category: 'data',
    priority: 1,
    tags: ['core', 'grammar'],
    capabilities: ['verbConjugation'],
    lazy: false,
    dependencies: ['languageDatabase'],
    lifecycle: class {
      async initialize(context, signal) {
        const db = await context.registry?.getEngine?.('languageDatabase');
        this._instance = db?.resolveConjugation?.bind(db);
        return this._instance;
      }
      async dispose() {
        this._instance = null;
      }
    }
  }),
  Object.freeze({
    id: 'grammar',
    version: '1.0.0',
    apiVersion: '1.0.0',
    minimumAppVersion: '6.0.2',
    description: 'Grammar analysis and error detection',
    category: 'core',
    priority: 2,
    tags: ['core', 'analysis'],
    capabilities: ['errorDetection', 'correction'],
    lazy: false,
    dependencies: ['languageDatabase'],
    lifecycle: class {
      async initialize(context, signal) {
        this._instance = getGrammarEngine();
        return this._instance;
      }
      async dispose() {
        this._instance = null;
      }
    }
  }),
  Object.freeze({
    id: 'translator',
    version: '1.0.0',
    apiVersion: '1.0.0',
    minimumAppVersion: '6.0.2',
    description: 'Offline translation engine with grammar awareness',
    category: 'core',
    priority: 3,
    tags: ['core', 'translation'],
    capabilities: ['translate', 'reverseTranslate'],
    lazy: false,
    dependencies: ['languageDatabase', 'grammar'],
    lifecycle: class {
      async initialize(context, signal) {
        this._instance = getTranslator();
        return this._instance;
      }
      async dispose() {
        this._instance = null;
      }
    }
  }),
  Object.freeze({
    id: 'tutor',
    version: '1.0.0',
    apiVersion: '1.0.0',
    minimumAppVersion: '6.0.2',
    description: 'AI tutor engine with student model and adaptive responses',
    category: 'core',
    priority: 4,
    tags: ['core', 'ai'],
    capabilities: ['studentTracking', 'adaptiveResponse'],
    lazy: false,
    dependencies: ['languageDatabase', 'grammar', 'translator'],
    lifecycle: class {
      async initialize(context, signal) {
        this._instance = getTutorEngine();
        return this._instance;
      }
      async dispose() {
        this._instance = null;
      }
    }
  }),
  Object.freeze({
    id: 'learningGraph',
    version: '1.0.0',
    apiVersion: '1.0.0',
    minimumAppVersion: '6.0.2',
    description: 'Semantic graph connecting vocabulary, grammar, and topics',
    category: 'core',
    priority: 2,
    tags: ['core', 'semantic'],
    capabilities: ['wordConnections', 'topicGraph'],
    lazy: false,
    dependencies: ['languageDatabase'],
    lifecycle: class {
      async initialize(context, signal) {
        this._instance = getLearningGraphEngine();
        return this._instance;
      }
      async dispose() {
        this._instance = null;
      }
    }
  }),
  Object.freeze({
    id: 'reasoning',
    version: '1.0.0',
    apiVersion: '1.0.0',
    minimumAppVersion: '6.0.2',
    description: 'Deep sentence analysis and logical reasoning engine',
    category: 'advanced',
    priority: 5,
    tags: ['advanced', 'ai'],
    capabilities: ['sentenceAnalysis', 'contextAwareness'],
    lazy: true,
    dependencies: ['languageDatabase', 'grammar'],
    lifecycle: class {
      async initialize(context, signal) {
        this._instance = getReasoningEngine();
        return this._instance;
      }
      async dispose() {
        this._instance = null;
      }
    }
  }),
  Object.freeze({
    id: 'conversationAI',
    version: '1.0.0',
    apiVersion: '1.0.0',
    minimumAppVersion: '6.0.2',
    description: 'Natural conversation generation with context awareness',
    category: 'advanced',
    priority: 5,
    tags: ['advanced', 'ai', 'conversation'],
    capabilities: ['responseGeneration', 'contextMemory'],
    lazy: true,
    dependencies: ['languageDatabase', 'tutor'],
    lifecycle: class {
      async initialize(context, signal) {
        this._instance = getConversationAI();
        return this._instance;
      }
      async dispose() {
        this._instance = null;
      }
    }
  }),
  Object.freeze({
    id: 'lessonGenerator',
    version: '1.0.0',
    apiVersion: '1.0.0',
    minimumAppVersion: '6.0.2',
    description: 'Adaptive lesson generation based on student profile',
    category: 'advanced',
    priority: 5,
    tags: ['advanced', 'learning'],
    capabilities: ['adaptiveLesson', 'quizGeneration'],
    lazy: true,
    dependencies: ['languageDatabase', 'tutor'],
    lifecycle: class {
      async initialize(context, signal) {
        this._instance = getLessonGenerator();
        return this._instance;
      }
      async dispose() {
        this._instance = null;
      }
    }
  })
]);