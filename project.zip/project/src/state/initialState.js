// src/state/initialState.js
import { APP_VERSION } from '../constants';
import { deepFreeze } from '../utils/object';

export const INITIAL_STATE = {
  student: {
    name: "Taha",
    level: "A1",
    xp: 0,
    streak: 0,
    accuracy: 100,
    totalAttempts: 0,
    totalCorrect: 0,
    knownWords: [],
    weakWords: [],
    mistakes: {
      verbs: {},
      accents: {},
      gender: {},
      vocabulary: {},
      punctuation: {},
      serEstar: {},
      prepositions: {}
    },
    achievements: []
  },
  chat: {
    history: [],
    draftMessage: ""
  },
  translator: {
    input: "",
    output: "",
    direction: "en",
    history: []
  },
  flashcards: {
    currentDeckId: null,
    currentCardIndex: 0,
    isShuffled: false
  },
  ui: {
    activeTab: "home"
  },
  lessons: {
    current: null,
    completed: []
  },
  version: APP_VERSION
};

export function createInitialState() {
  const state = typeof structuredClone === 'function'
    ? structuredClone(INITIAL_STATE)
    : JSON.parse(JSON.stringify(INITIAL_STATE));
  
  if (import.meta.env && import.meta.env.DEV) {
    return deepFreeze(state);
  }
  return state;
}