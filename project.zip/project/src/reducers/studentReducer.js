// src/reducers/studentReducer.js
export function studentReducer(state, action) {
  switch (action.type) {
    case 'SET_STUDENT_NAME':
      return { ...state, name: action.payload };
    case 'ADD_KNOWN_WORD': {
      const knownWords = state.knownWords || [];
      if (knownWords.includes(action.payload)) return state;
      return {
        ...state,
        knownWords: [...knownWords, action.payload],
        weakWords: (state.weakWords || []).filter((w) => w !== action.payload)
      };
    }
    case 'UPDATE_STUDENT_LEVEL':
      return { ...state, level: action.payload };
    case 'ADD_XP':
      return { ...state, xp: (state.xp || 0) + action.payload };
    case 'UPDATE_STREAK':
      return { ...state, streak: action.payload };
    case 'UPDATE_ACCURACY': {
      // payload: { correct, attempts } — deltas for this session, accumulated centrally
      const totalAttempts = (state.totalAttempts || 0) + (action.payload?.attempts || 0);
      const totalCorrect = (state.totalCorrect || 0) + (action.payload?.correct || 0);
      const accuracy = totalAttempts > 0
        ? Math.round((totalCorrect / totalAttempts) * 100)
        : state.accuracy;
      return { ...state, totalAttempts, totalCorrect, accuracy };
    }
    default:
      return state;
  }
}