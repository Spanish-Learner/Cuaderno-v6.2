// src/utils/errors.js

export class BootError extends Error {
  constructor(message, options = {}) {
    super(message, { cause: options.cause });
    this.name = 'BootError';
    this.code = options.code || 'UNKNOWN_ERROR';
    this.severity = options.severity || 'fatal';
    this.recoverable = options.recoverable || false;
    this.phase = options.phase || 'unknown';
    this.details = options.details || {};
  }
}