// src/utils/object.js

export function deepClone(obj) {
  if (typeof structuredClone === 'function') {
    try {
      return structuredClone(obj);
    } catch (_) {
      return fallbackClone(obj);
    }
  }
  return fallbackClone(obj);
}

function fallbackClone(obj) {
  if (obj === null || typeof obj !== 'object') return obj;
  if (obj instanceof Date) return new Date(obj);
  if (Array.isArray(obj)) {
    return obj.map(item => fallbackClone(item));
  }
  const cloned = {};
  for (const key of Object.keys(obj)) {
    cloned[key] = fallbackClone(obj[key]);
  }
  return cloned;
}

export function deepFreeze(obj, visited = new WeakSet()) {
  if (!obj || typeof obj !== 'object') return obj;
  if (visited.has(obj)) return obj;
  visited.add(obj);

  Object.freeze(obj);
  for (const key of Object.keys(obj)) {
    deepFreeze(obj[key], visited);
  }
  return obj;
}