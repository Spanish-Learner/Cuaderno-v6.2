// src/components/Home.jsx
import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { getBootManager } from '../engine/bootManager';
import { eventBus } from '../eventBus';
import { APP_VERSION } from '../constants';
import useLearningGraph from '../hooks/useLearningGraph';

export default function Home() {
  const { state, dispatch } = useApp();
  const [systemStatus, setSystemStatus] = useState({
    booted: false,
    error: null,
    engineStatuses: {},
    version: APP_VERSION
  });

  useEffect(() => {
    const bootManager = getBootManager();
    const context = bootManager.getContext();
    setSystemStatus(prev => ({
      ...prev,
      booted: context.booted,
      error: context.error,
      engineStatuses: context.reporter?.getReport()?.engines || {}
    }));
  }, []);

  const navigate = (tab) => {
    dispatch({ type: 'SET_TAB', payload: tab });
  };

  const { recommendations } = useLearningGraph();

  const student = state?.student;
  const currentLesson = state?.lessons?.current;
  const formatDate = () => new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' });
  const formatTime = () => new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });

  return (
    <div className="home-container">
      <div className="home-header">
        <div className="greeting">
          <h1>Welcome back{student?.name ? `, ${student.name}` : ''}</h1>
          <div className="date-time">
            <span>{formatDate()}</span>
            <span className="time">{formatTime()}</span>
          </div>
        </div>
        <div className="system-status">
          <span className="status-dot">{systemStatus.error ? '🔴' : systemStatus.booted ? '🟢' : '🟡'}</span>
          <span className="status-label">{systemStatus.error ? 'Error' : systemStatus.booted ? 'Ready' : 'Booting...'}</span>
        </div>
      </div>

      {/* Current Session */}
      <section className="home-section">
        <h2>Current Session</h2>
        {currentLesson ? (
          <div className="session-card">
            <div className="session-info">
              <h3>{currentLesson.title}</h3>
              <p>Progress: {currentLesson.progress || 0} / {currentLesson.total || 0} completed</p>
              <div className="progress-bar">
                <div className="progress-fill" style={{ width: `${((currentLesson.progress || 0) / (currentLesson.total || 1)) * 100}%` }} />
              </div>
              {currentLesson.estimatedMinutesRemaining !== undefined ? (
                <p className="time-estimate">
                  Estimated time remaining: {currentLesson.estimatedMinutesRemaining} minutes
                </p>
              ) : (
                <p className="time-estimate">
                  Time estimate unavailable
                </p>
              )}
            </div>
            <button className="btn-primary" onClick={() => navigate('lessons')}>Resume</button>
          </div>
        ) : (
          <div className="session-card empty">
            <p>No active lesson.</p>
            <button className="btn-primary" onClick={() => navigate('lessons')}>Generate Lesson</button>
          </div>
        )}
      </section>

      {/* Quick Actions */}
      <section className="home-section">
        <h2>Quick Actions</h2>
        <div className="quick-actions-grid">
          <button className="action-card" onClick={() => navigate('lessons')}>
            <span className="icon">📚</span>
            <span className="label">Start Lesson</span>
          </button>
          <button className="action-card" onClick={() => navigate('chat')}>
            <span className="icon">💬</span>
            <span className="label">Chat</span>
          </button>
          <button className="action-card" onClick={() => navigate('practice')}>
            <span className="icon">📝</span>
            <span className="label">Practice</span>
          </button>
          <button className="action-card" onClick={() => navigate('settings')}>
            <span className="icon">⚙️</span>
            <span className="label">Settings</span>
          </button>
        </div>
      </section>

      {/* Overview */}
      <section className="home-section">
        <h2>Overview</h2>
        <div className="overview-grid">
          <div className="stat-card">
            <span className="stat-value">{student?.level || 'A1'}</span>
            <span className="stat-label">Level</span>
          </div>
          <div className="stat-card">
            <span className="stat-value">{student?.xp || 0}</span>
            <span className="stat-label">XP</span>
          </div>
          <div className="stat-card">
            <span className="stat-value">{student?.accuracy || 0}%</span>
            <span className="stat-label">Accuracy</span>
          </div>
          <div className="stat-card">
            <span className="stat-value">{student?.streak || 0}</span>
            <span className="stat-label">Day Streak</span>
          </div>
        </div>
      </section>

      {/* Adaptive Recommendations */}
      <section className="home-section">
        <h2>Recommended Next</h2>
        {recommendations && recommendations.length > 0 ? (
          <div className="recommendations-grid">
            {recommendations.slice(0, 6).map((rec) => (
              <div key={rec.id} className="recommendation-card">
                <span className="recommendation-label">{rec.label}</span>
                <span className="recommendation-category">{rec.category}</span>
              </div>
            ))}
          </div>
        ) : (
          <div className="empty-state">
            <p>Keep learning words to unlock personalized recommendations.</p>
          </div>
        )}
      </section>

      {/* Recent Activity */}
      <section className="home-section">
        <h2>Recent Activity</h2>
        <div className="activity-list">
          {state?.chat?.history?.slice(-3).reverse().map((msg, i) => (
            <div key={i} className="activity-item">
              <span className="activity-icon">{msg.from === 'tutor' ? '🤖' : '👤'}</span>
              <div className="activity-content">
                <div className="activity-text">{msg.es || msg.text}</div>
                <div className="activity-time">Recent</div>
              </div>
            </div>
          ))}
          {(!state?.chat?.history || state.chat.history.length === 0) && (
            <div className="activity-item">
              <span className="activity-text">No recent activity. Start a conversation!</span>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}