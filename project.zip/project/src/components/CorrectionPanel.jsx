// src/components/CorrectionPanel.jsx
import React from "react";

export default function CorrectionPanel({ correction }) {
  if (!correction) return null;

  return (
    <div className="correction-panel">
      <h3>📝 Correction</h3>
      <p>
        <strong>Original:</strong>
        <br />
        <span className="wrong">{correction.original}</span>
      </p>
      <p>
        <strong>Correct:</strong>
        <br />
        <span className="correct">{correction.corrected}</span>
      </p>
      {correction.reasons && correction.reasons.length > 0 && (
        <>
          <h4>Why?</h4>
          <ul>
            {correction.reasons.map((reason, i) => (
              <li key={i}>{reason}</li>
            ))}
          </ul>
        </>
      )}
    </div>
  );
}