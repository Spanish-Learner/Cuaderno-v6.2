// src/components/FlashcardsTab.jsx
import React, { useMemo, useState } from 'react';
import { useApp } from '../context/AppContext';
import { PRESET_DECKS } from '../data/decks';

export default function FlashcardsTab() {
  const { state, dispatch } = useApp();
  const [flipped, setFlipped] = useState(false);

  const deckId = state?.flashcards?.currentDeckId;
  const cardIndex = state?.flashcards?.currentCardIndex || 0;
  const isShuffled = state?.flashcards?.isShuffled || false;

  const deck = useMemo(
    () => PRESET_DECKS.find((d) => d.id === deckId) || null,
    [deckId]
  );

  const order = useMemo(() => {
    if (!deck) return [];
    const base = deck.cards.map((_, i) => i);
    if (!isShuffled) return base;
    // Deterministic per-deck shuffle so it doesn't reshuffle on every render
    const shuffled = [...base];
    let seed = deck.cards.length;
    for (let i = shuffled.length - 1; i > 0; i--) {
      seed = (seed * 9301 + 49297) % 233280;
      const j = Math.floor((seed / 233280) * (i + 1));
      [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    return shuffled;
  }, [deck, isShuffled]);

  const currentCard = deck && order.length > 0
    ? deck.cards[order[cardIndex % order.length]]
    : null;

  const selectDeck = (id) => {
    dispatch({ type: 'SET_FLASHCARD_DECK', payload: id });
    setFlipped(false);
  };

  const nextCard = () => {
    if (!deck) return;
    dispatch({ type: 'SET_FLASHCARD_INDEX', payload: (cardIndex + 1) % deck.cards.length });
    setFlipped(false);
  };

  const previousCard = () => {
    if (!deck) return;
    const total = deck.cards.length;
    dispatch({ type: 'SET_FLASHCARD_INDEX', payload: (cardIndex - 1 + total) % total });
    setFlipped(false);
  };

  const toggleShuffle = () => {
    dispatch({ type: 'TOGGLE_FLASHCARD_SHUFFLE' });
    dispatch({ type: 'SET_FLASHCARD_INDEX', payload: 0 });
    setFlipped(false);
  };

  if (!deck) {
    return (
      <div className="flashcards-tab">
        <div className="flashcards-header">
          <h2>🃏 Flashcards</h2>
          <p>Pick a deck to start reviewing.</p>
        </div>
        <div className="deck-list">
          {PRESET_DECKS.map((d) => (
            <button key={d.id} className="deck-card" onClick={() => selectDeck(d.id)}>
              <span className="deck-icon">{d.icon}</span>
              <span className="deck-name">{d.name}</span>
              <span className="deck-count">{d.cards.length} cards</span>
            </button>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="flashcards-tab">
      <div className="flashcards-header">
        <h2>🃏 {deck.name}</h2>
        <p>Card {cardIndex % deck.cards.length + 1} of {deck.cards.length}</p>
      </div>
      <div className="flashcard-view">
        <div className="flashcard-card" onClick={() => setFlipped(!flipped)}>
          <div className={flipped ? 'flashcard-back' : 'flashcard-front'}>
            {flipped ? currentCard?.back : currentCard?.front}
          </div>
        </div>
        <div className="flashcard-controls">
          <button className="btn-secondary" onClick={previousCard}>← Prev</button>
          <button className="btn-secondary" onClick={() => setFlipped(!flipped)}>Flip</button>
          <button className="btn-secondary" onClick={nextCard}>Next →</button>
        </div>
        <div className="flashcard-controls">
          <button className={`btn-secondary ${isShuffled ? 'active' : ''}`} onClick={toggleShuffle}>
            {isShuffled ? '🔀 Shuffled' : 'Shuffle'}
          </button>
          <button className="btn-secondary" onClick={() => selectDeck(null)}>Change Deck</button>
        </div>
      </div>
    </div>
  );
}
