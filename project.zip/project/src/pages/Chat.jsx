// src/pages/Chat.jsx
import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import useTutor from '../hooks/useTutor';
import CorrectionPanel from '../components/CorrectionPanel';

export default function Chat() {
  const { state, dispatch } = useApp();
  const { sendMessage } = useTutor();
  const [sending, setSending] = useState(false);
  const [lastCorrection, setLastCorrection] = useState(null);

  const history = state?.chat?.history || [];
  const draft = state?.chat?.draftMessage || '';

  const setDraft = (value) => {
    dispatch({ type: 'SET_CHAT_DRAFT', payload: value });
  };

  const handleSend = () => {
    const message = draft.trim();
    if (!message || sending) return;

    setSending(true);
    dispatch({ type: 'ADD_CHAT_MESSAGE', payload: { from: 'user', text: message } });
    setDraft('');

    const result = sendMessage(message);

    if (result?.correction?.reasons?.length > 0) {
      setLastCorrection(result.correction);
    } else {
      setLastCorrection(null);
    }

    dispatch({ type: 'ADD_CHAT_MESSAGE', payload: { from: 'tutor', es: result?.response } });

    // Feed the correction result into the shared accuracy stats so
    // Home/Overview reflects what the tutor engine caught for this message.
    const hadMistake = result?.correction?.reasons?.length > 0;
    dispatch({ type: 'UPDATE_ACCURACY', payload: { correct: hadMistake ? 0 : 1, attempts: 1 } });

    setSending(false);
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter') handleSend();
  };

  return (
    <div className="page-container">
      <div className="page-header">
        <h1>💬 Chat</h1>
      </div>

      <div className="chat-window">
        {history.length === 0 && (
          <p className="empty-state">Say ¡hola! to start practicing conversation.</p>
        )}
        {history.map((msg, i) => (
          <div key={i} className={`chat-bubble ${msg.from === 'tutor' ? 'tutor' : 'user'}`}>
            {msg.es || msg.text}
          </div>
        ))}
      </div>

      {lastCorrection && <CorrectionPanel correction={lastCorrection} />}

      <div className="chat-input-row">
        <input
          type="text"
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Escribe en español..."
        />
        <button className="btn-primary" onClick={handleSend} disabled={sending}>Send</button>
      </div>
    </div>
  );
}
