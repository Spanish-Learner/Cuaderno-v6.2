// src/pages/Translator.jsx
import React from 'react';
import { useApp } from '../context/AppContext';
import { getTranslator } from '../engine/translator';
import { DICTIONARY } from '../data/dictionary';

export default function Translator() {
  const { state, dispatch } = useApp();
  const translator = getTranslator();

  const input = state?.translator?.input || '';
  const output = state?.translator?.output || '';
  const direction = state?.translator?.direction || 'en'; // 'en' = es->en, 'es' = en->es
  const history = state?.translator?.history || [];

  const setInput = (value) => dispatch({ type: 'SET_TRANSLATOR_INPUT', payload: value });

  const toggleDirection = () => {
    dispatch({ type: 'SET_TRANSLATOR_DIRECTION', payload: direction === 'en' ? 'es' : 'en' });
    dispatch({ type: 'SET_TRANSLATOR_OUTPUT', payload: '' });
  };

  const handleTranslate = () => {
    const text = input.trim();
    if (!text) return;

    const result = direction === 'en'
      ? translator.translateSpanishToEnglish(text, DICTIONARY)
      : translator.translateEnglishToSpanish(text, DICTIONARY);

    dispatch({ type: 'SET_TRANSLATOR_OUTPUT', payload: result });
    dispatch({
      type: 'ADD_TRANSLATOR_HISTORY',
      payload: { input: text, output: result, direction, timestamp: Date.now() }
    });
  };

  return (
    <div className="page-container">
      <div className="page-header">
        <h1>🌐 Translator</h1>
      </div>

      <div className="translator-direction">
        <span>{direction === 'en' ? 'Spanish' : 'English'}</span>
        <button className="btn-secondary" onClick={toggleDirection}>⇄</button>
        <span>{direction === 'en' ? 'English' : 'Spanish'}</span>
      </div>

      <div className="translator-box">
        <textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder={direction === 'en' ? 'Escribe en español...' : 'Type in English...'}
        />
        <button className="btn-primary" onClick={handleTranslate}>Translate</button>
        <div className="translator-output">{output || 'Translation will appear here.'}</div>
      </div>

      {history.length > 0 && (
        <div className="translator-history">
          <h2>Recent</h2>
          {history.slice(-5).reverse().map((item, i) => (
            <div key={i} className="translator-history-item">
              <div className="from">{item.input}</div>
              <div className="to">{item.output}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
