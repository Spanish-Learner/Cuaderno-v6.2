// src/pages/Students.jsx
import React from 'react';
import { useApp } from '../context/AppContext';

export default function Students() {
  const { state } = useApp();
  const student = state?.student;

  return (
    <div className="page-container">
      <div className="page-header">
        <h1>👨‍🎓 Students</h1>
        <button className="btn-primary" disabled>+ Add Student (Coming soon)</button>
      </div>
      
      <div className="students-grid">
        <div className="student-card">
          <div className="student-avatar">👤</div>
          <div className="student-info">
            <h3>{student?.name || 'Current Student'}</h3>
            <p>Level: {student?.level || 'A1'}</p>
            <p>Progress: {student?.accuracy || 0}%</p>
          </div>
          <button className="btn-secondary" disabled>Selected</button>
        </div>
      </div>
    </div>
  );
}