// src/pages/Practice.jsx
import React from 'react';
import { useApp } from '../context/AppContext';

export default function Practice() {
  const { dispatch } = useApp();

  const navigate = (tab) => {
    dispatch({ type: 'SET_TAB', payload: tab });
  };

  return (
    <div className="page-container">
      <div className="page-header">
        <h1>📝 Practice</h1>
      </div>

      <div className="practice-grid">
        <div className="practice-card" onClick={() => navigate('flashcards')}>
          <div className="practice-icon">🃏</div>
          <h3>Flashcard Review</h3>
          <p>Review your vocabulary decks.</p>
          <button className="btn-secondary">Start</button>
        </div>

        <div className="practice-card" onClick={() => navigate('translate')}>
          <div className="practice-icon">🌐</div>
          <h3>Translation Practice</h3>
          <p>Translate sentences and check your answers.</p>
          <button className="btn-secondary">Start</button>
        </div>
      </div>
    </div>
  );
}