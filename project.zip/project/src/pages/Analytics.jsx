// src/pages/Analytics.jsx
import React from 'react';
import { useApp } from '../context/AppContext';
import { getStudentStats } from '../engine/studentModel';

export default function Analytics() {
  const { state } = useApp();
  const stats = getStudentStats(state?.student);

  return (
    <div className="page-container">
      <div className="page-header">
        <h1>📊 Analytics</h1>
      </div>

      <div className="analytics-grid">
        <div className="stat-card">
          <div className="stat-value">{stats.level}</div>
          <div className="stat-label">Current Level</div>
        </div>
        <div className="stat-card">
          <div className="stat-value">{stats.xp}</div>
          <div className="stat-label">Total XP</div>
        </div>
        <div className="stat-card">
          <div className="stat-value">{stats.accuracy}%</div>
          <div className="stat-label">Accuracy</div>
        </div>
        <div className="stat-card">
          <div className="stat-value">{stats.streak}</div>
          <div className="stat-label">Day Streak</div>
        </div>
        <div className="stat-card">
          <div className="stat-value">{stats.knownWords}</div>
          <div className="stat-label">Words Learned</div>
        </div>
        <div className="stat-card">
          <div className="stat-value">{stats.sessionsCompleted}</div>
          <div className="stat-label">Sessions Completed</div>
        </div>
      </div>

      <div className="weak-areas-section">
        <h2>Weak Areas</h2>
        <div className="weak-list">
          {stats.mistakes && Object.entries(stats.mistakes)
            .map(([area, reasons]) => [area, Object.values(reasons || {}).reduce((a, b) => a + b, 0)])
            .filter(([, count]) => count > 0)
            .map(([area, count]) => (
              <div key={area} className="weak-item">
                <span>{area}</span>
                <span className="mistake-count">{count} mistakes</span>
              </div>
            ))}
          {(!stats.mistakes || Object.values(stats.mistakes).every(reasons => Object.keys(reasons || {}).length === 0)) && (
            <p className="empty-state">No mistakes recorded yet. Keep practicing!</p>
          )}
        </div>
      </div>
    </div>
  );
}