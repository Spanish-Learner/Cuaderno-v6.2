// src/pages/Lessons.jsx
import React, { useEffect } from 'react';
import { useApp } from '../context/AppContext';
import useLessonGenerator from '../hooks/useLessonGenerator';
import LessonView from '../components/LessonView';
import { checkLevelUp } from '../engine/studentModel';

export default function Lessons() {
  const { state, dispatch } = useApp();
  const { lesson, generateAdaptive, completeLesson, loading } = useLessonGenerator();

  // Keep the global store's "current lesson" (used by the Home dashboard)
  // in sync with whatever the generator hook currently has active.
  useEffect(() => {
    dispatch({ type: 'SET_CURRENT_LESSON', payload: lesson || null });
  }, [lesson, dispatch]);

  const handleGenerateLesson = () => {
    generateAdaptive();
  };

  const handleCompleteLesson = (lessonId, { correct = 0, attempts = 0, review = [] } = {}) => {
    completeLesson(lessonId);
    dispatch({ type: 'LESSON_COMPLETED', payload: { id: lessonId } });

    const xpEarned = 20 + correct * 10;
    dispatch({ type: 'ADD_XP', payload: xpEarned });
    if (attempts > 0) {
      dispatch({ type: 'UPDATE_ACCURACY', payload: { correct, attempts } });
    }
    dispatch({ type: 'UPDATE_STREAK', payload: (state.student?.streak || 0) + 1 });
    review.forEach((word) => {
      if (word?.front) dispatch({ type: 'ADD_KNOWN_WORD', payload: word.front });
    });

    const projectedStudent = { ...state.student, xp: (state.student?.xp || 0) + xpEarned };
    const leveled = checkLevelUp(projectedStudent);
    if (leveled.level !== state.student?.level) {
      dispatch({ type: 'UPDATE_STUDENT_LEVEL', payload: leveled.level });
    }
  };

  return (
    <div className="page-container">
      <div className="page-header">
        <h1>📚 Lessons</h1>
        <button className="btn-primary" onClick={handleGenerateLesson} disabled={loading}>
          {loading ? 'Generating...' : 'Generate Adaptive Lesson'}
        </button>
      </div>

      {lesson && (
        <div className="active-lesson-container">
          <LessonView lesson={lesson} onComplete={handleCompleteLesson} />
        </div>
      )}

      {!lesson && !loading && (
        <div className="empty-state">
          <p>No active lesson. Click "Generate Adaptive Lesson" to start based on your recent mistakes.</p>
        </div>
      )}
    </div>
  );
}