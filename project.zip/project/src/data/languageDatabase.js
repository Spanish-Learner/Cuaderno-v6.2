// src/data/languageDatabase.js
// Centralized offline Spanish language database

// ============================================================
// WORD ENTRIES
// ============================================================

export const WORDS = [
  // === NOUNS ===
  { id: 101, word: "casa", type: "noun", gender: "feminine", plural: "casas", english: "house", level: "A1", frequency: 100, tags: ["house", "daily", "core"] },
  { id: 102, word: "perro", type: "noun", gender: "masculine", plural: "perros", english: "dog", level: "A1", frequency: 92, tags: ["animals", "daily"] },
  { id: 103, word: "gato", type: "noun", gender: "masculine", plural: "gatos", english: "cat", level: "A1", frequency: 90, tags: ["animals", "daily"] },
  { id: 104, word: "agua", type: "noun", gender: "feminine", plural: "aguas", english: "water", level: "A1", frequency: 100, tags: ["food", "daily", "core"] },
  { id: 105, word: "comida", type: "noun", gender: "feminine", plural: "comidas", english: "food", level: "A1", frequency: 98, tags: ["food", "daily", "core"] },
  { id: 106, word: "escuela", type: "noun", gender: "feminine", plural: "escuelas", english: "school", level: "A1", frequency: 95, tags: ["education", "daily"] },
  { id: 107, word: "libro", type: "noun", gender: "masculine", plural: "libros", english: "book", level: "A1", frequency: 96, tags: ["education", "daily"] },
  { id: 108, word: "amigo", type: "noun", gender: "masculine", plural: "amigos", english: "friend (m)", level: "A1", frequency: 97, tags: ["people", "daily"] },
  { id: 109, word: "amiga", type: "noun", gender: "feminine", plural: "amigas", english: "friend (f)", level: "A1", frequency: 97, tags: ["people", "daily"] },
  { id: 110, word: "familia", type: "noun", gender: "feminine", plural: "familias", english: "family", level: "A1", frequency: 99, tags: ["people", "daily", "core"] },
  { id: 111, word: "ciudad", type: "noun", gender: "feminine", plural: "ciudades", english: "city", level: "A1", frequency: 96, tags: ["places", "daily"] },
  { id: 112, word: "país", type: "noun", gender: "masculine", plural: "países", english: "country", level: "A1", frequency: 98, tags: ["places", "daily"] },
  { id: 113, word: "mundo", type: "noun", gender: "masculine", plural: "mundos", english: "world", level: "A1", frequency: 99, tags: ["daily", "core"] },
  { id: 114, word: "tiempo", type: "noun", gender: "masculine", plural: "tiempos", english: "time / weather", level: "A1", frequency: 100, tags: ["daily", "core"] },
  { id: 115, word: "año", type: "noun", gender: "masculine", plural: "años", english: "year", level: "A1", frequency: 100, tags: ["time", "daily", "core"] },
  { id: 116, word: "día", type: "noun", gender: "masculine", plural: "días", english: "day", level: "A1", frequency: 100, tags: ["time", "daily", "core"] },
  { id: 117, word: "noche", type: "noun", gender: "feminine", plural: "noches", english: "night", level: "A1", frequency: 98, tags: ["time", "daily"] },
  { id: 118, word: "semana", type: "noun", gender: "feminine", plural: "semanas", english: "week", level: "A1", frequency: 98, tags: ["time", "daily"] },
  { id: 119, word: "mes", type: "noun", gender: "masculine", plural: "meses", english: "month", level: "A1", frequency: 98, tags: ["time", "daily"] },
  { id: 120, word: "persona", type: "noun", gender: "feminine", plural: "personas", english: "person", level: "A1", frequency: 100, tags: ["people", "daily", "core"] },
  
  // === FOOD ===
  { id: 201, word: "pan", type: "noun", gender: "masculine", plural: "panes", english: "bread", level: "A1", frequency: 95, tags: ["food", "daily"] },
  { id: 202, word: "queso", type: "noun", gender: "masculine", plural: "quesos", english: "cheese", level: "A1", frequency: 94, tags: ["food", "daily"] },
  { id: 203, word: "leche", type: "noun", gender: "feminine", plural: "leches", english: "milk", level: "A1", frequency: 96, tags: ["food", "daily"] },
  { id: 204, word: "huevo", type: "noun", gender: "masculine", plural: "huevos", english: "egg", level: "A1", frequency: 95, tags: ["food", "daily"] },
  { id: 205, word: "carne", type: "noun", gender: "feminine", plural: "carnes", english: "meat", level: "A1", frequency: 94, tags: ["food", "daily"] },
  { id: 206, word: "fruta", type: "noun", gender: "feminine", plural: "frutas", english: "fruit", level: "A1", frequency: 96, tags: ["food", "daily"] },
  { id: 207, word: "manzana", type: "noun", gender: "feminine", plural: "manzanas", english: "apple", level: "A1", frequency: 93, tags: ["food", "daily"] },
  { id: 208, word: "plátano", type: "noun", gender: "masculine", plural: "plátanos", english: "banana", level: "A1", frequency: 92, tags: ["food", "daily"] },
  { id: 209, word: "naranja", type: "noun", gender: "feminine", plural: "naranjas", english: "orange", level: "A1", frequency: 92, tags: ["food", "daily", "colors"] },
  { id: 210, word: "tomate", type: "noun", gender: "masculine", plural: "tomates", english: "tomato", level: "A1", frequency: 93, tags: ["food", "daily"] },
  { id: 211, word: "ensalada", type: "noun", gender: "feminine", plural: "ensaladas", english: "salad", level: "A1", frequency: 92, tags: ["food", "daily"] },
  { id: 212, word: "sopa", type: "noun", gender: "feminine", plural: "sopas", english: "soup", level: "A1", frequency: 91, tags: ["food", "daily"] },
  
  // === ANIMALS ===
  { id: 301, word: "pájaro", type: "noun", gender: "masculine", plural: "pájaros", english: "bird", level: "A1", frequency: 85, tags: ["animals"] },
  { id: 302, word: "caballo", type: "noun", gender: "masculine", plural: "caballos", english: "horse", level: "A1", frequency: 82, tags: ["animals"] },
  { id: 303, word: "vaca", type: "noun", gender: "feminine", plural: "vacas", english: "cow", level: "A1", frequency: 80, tags: ["animals"] },
  { id: 304, word: "cerdo", type: "noun", gender: "masculine", plural: "cerdos", english: "pig", level: "A1", frequency: 78, tags: ["animals"] },
  { id: 305, word: "oveja", type: "noun", gender: "feminine", plural: "ovejas", english: "sheep", level: "A1", frequency: 76, tags: ["animals"] },
  { id: 306, word: "pez", type: "noun", gender: "masculine", plural: "peces", english: "fish", level: "A1", frequency: 84, tags: ["animals", "food"] },
  { id: 307, word: "león", type: "noun", gender: "masculine", plural: "leones", english: "lion", level: "A1", frequency: 75, tags: ["animals"] },
  { id: 308, word: "tigre", type: "noun", gender: "masculine", plural: "tigres", english: "tiger", level: "A1", frequency: 74, tags: ["animals"] },
  { id: 309, word: "oso", type: "noun", gender: "masculine", plural: "osos", english: "bear", level: "A1", frequency: 73, tags: ["animals"] },
  
  // === VERBS ===
  { id: 401, word: "ser", type: "verb", english: "be", group: "er", regular: false, level: "A1", frequency: 100, tags: ["core", "essential"] },
  { id: 402, word: "estar", type: "verb", english: "be (location/state)", group: "ar", regular: false, level: "A1", frequency: 100, tags: ["core", "essential"] },
  { id: 403, word: "tener", type: "verb", english: "have", group: "er", regular: false, level: "A1", frequency: 100, tags: ["core", "essential"] },
  { id: 404, word: "hacer", type: "verb", english: "do/make", group: "er", regular: false, level: "A1", frequency: 99, tags: ["core", "essential"] },
  { id: 405, word: "decir", type: "verb", english: "say/tell", group: "ir", regular: false, level: "A1", frequency: 98, tags: ["core", "essential"] },
  { id: 406, word: "ir", type: "verb", english: "go", group: "ir", regular: false, level: "A1", frequency: 100, tags: ["core", "essential"] },
  { id: 407, word: "venir", type: "verb", english: "come", group: "ir", regular: false, level: "A1", frequency: 95, tags: ["core"] },
  { id: 408, word: "poder", type: "verb", english: "can/be able to", group: "er", regular: false, level: "A1", frequency: 99, tags: ["core", "essential"] },
  { id: 409, word: "querer", type: "verb", english: "want/love", group: "er", regular: false, level: "A1", frequency: 98, tags: ["core", "essential"] },
  { id: 410, word: "saber", type: "verb", english: "know", group: "er", regular: false, level: "A1", frequency: 97, tags: ["core", "essential"] },
  { id: 411, word: "hablar", type: "verb", english: "speak", group: "ar", regular: true, level: "A1", frequency: 98, tags: ["core", "essential"] },
  { id: 412, word: "comer", type: "verb", english: "eat", group: "er", regular: true, level: "A1", frequency: 97, tags: ["food", "daily"] },
  { id: 413, word: "vivir", type: "verb", english: "live", group: "ir", regular: true, level: "A1", frequency: 96, tags: ["daily"] },
  { id: 414, word: "tomar", type: "verb", english: "take/drink", group: "ar", regular: true, level: "A1", frequency: 95, tags: ["daily"] },
  { id: 415, word: "beber", type: "verb", english: "drink", group: "er", regular: true, level: "A1", frequency: 94, tags: ["food", "daily"] },
  { id: 416, word: "caminar", type: "verb", english: "walk", group: "ar", regular: true, level: "A1", frequency: 93, tags: ["daily"] },
  { id: 417, word: "trabajar", type: "verb", english: "work", group: "ar", regular: true, level: "A1", frequency: 98, tags: ["work", "daily"] },
  { id: 418, word: "estudiar", type: "verb", english: "study", group: "ar", regular: true, level: "A1", frequency: 97, tags: ["education", "daily"] },
  { id: 419, word: "leer", type: "verb", english: "read", group: "er", regular: true, level: "A1", frequency: 96, tags: ["education", "daily"] },
  { id: 420, word: "escribir", type: "verb", english: "write", group: "ir", regular: true, level: "A1", frequency: 95, tags: ["education", "daily"] },
  { id: 421, word: "mirar", type: "verb", english: "look/watch", group: "ar", regular: true, level: "A1", frequency: 95, tags: ["daily"] },
  { id: 422, word: "escuchar", type: "verb", english: "listen", group: "ar", regular: true, level: "A1", frequency: 94, tags: ["daily"] },
  { id: 423, word: "preguntar", type: "verb", english: "ask", group: "ar", regular: true, level: "A1", frequency: 94, tags: ["daily"] },
  { id: 424, word: "responder", type: "verb", english: "answer", group: "er", regular: true, level: "A1", frequency: 93, tags: ["daily"] },
  { id: 425, word: "entender", type: "verb", english: "understand", group: "er", regular: true, level: "A1", frequency: 96, tags: ["core"] },
  { id: 426, word: "necesitar", type: "verb", english: "need", group: "ar", regular: true, level: "A1", frequency: 97, tags: ["core", "essential"] },
  
  // === ADJECTIVES ===
  { id: 501, word: "bueno", type: "adjective", masculine: "bueno", feminine: "buena", pluralMasc: "buenos", pluralFem: "buenas", english: "good", level: "A1", frequency: 100, tags: ["core", "essential"] },
  { id: 502, word: "malo", type: "adjective", masculine: "malo", feminine: "mala", pluralMasc: "malos", pluralFem: "malas", english: "bad", level: "A1", frequency: 98, tags: ["core"] },
  { id: 503, word: "grande", type: "adjective", masculine: "grande", feminine: "grande", pluralMasc: "grandes", pluralFem: "grandes", english: "big", level: "A1", frequency: 99, tags: ["core", "essential"] },
  { id: 504, word: "pequeño", type: "adjective", masculine: "pequeño", feminine: "pequeña", pluralMasc: "pequeños", pluralFem: "pequeñas", english: "small", level: "A1", frequency: 98, tags: ["core"] },
  { id: 505, word: "bonito", type: "adjective", masculine: "bonito", feminine: "bonita", pluralMasc: "bonitos", pluralFem: "bonitas", english: "pretty", level: "A1", frequency: 95, tags: ["daily"] },
  { id: 506, word: "feo", type: "adjective", masculine: "feo", feminine: "fea", pluralMasc: "feos", pluralFem: "feas", english: "ugly", level: "A1", frequency: 90, tags: ["daily"] },
  { id: 507, word: "feliz", type: "adjective", masculine: "feliz", feminine: "feliz", pluralMasc: "felices", pluralFem: "felices", english: "happy", level: "A1", frequency: 98, tags: ["core", "emotions"] },
  { id: 508, word: "triste", type: "adjective", masculine: "triste", feminine: "triste", pluralMasc: "tristes", pluralFem: "tristes", english: "sad", level: "A1", frequency: 96, tags: ["core", "emotions"] },
  { id: 509, word: "rojo", type: "adjective", masculine: "rojo", feminine: "roja", pluralMasc: "rojos", pluralFem: "rojas", english: "red", level: "A1", frequency: 95, tags: ["colors", "daily"] },
  { id: 510, word: "azul", type: "adjective", masculine: "azul", feminine: "azul", pluralMasc: "azules", pluralFem: "azules", english: "blue", level: "A1", frequency: 95, tags: ["colors", "daily"] },
  { id: 511, word: "verde", type: "adjective", masculine: "verde", feminine: "verde", pluralMasc: "verdes", pluralFem: "verdes", english: "green", level: "A1", frequency: 94, tags: ["colors", "daily"] },
  { id: 512, word: "amarillo", type: "adjective", masculine: "amarillo", feminine: "amarilla", pluralMasc: "amarillos", pluralFem: "amarillas", english: "yellow", level: "A1", frequency: 93, tags: ["colors", "daily"] },
  
  // === EXPRESSIONS ===
  { id: 601, word: "tener hambre", type: "expression", translation: "be hungry", priority: 100, level: "A1", tags: ["food", "daily"] },
  { id: 602, word: "tener sed", type: "expression", translation: "be thirsty", priority: 100, level: "A1", tags: ["food", "daily"] },
  { id: 603, word: "hacer frío", type: "expression", translation: "be cold (weather)", priority: 100, level: "A1", tags: ["weather", "daily"] },
  { id: 604, word: "hacer calor", type: "expression", translation: "be hot (weather)", priority: 100, level: "A1", tags: ["weather", "daily"] },
  { id: 605, word: "tener ... años", type: "expression", translation: "be ... years old", priority: 100, level: "A1", tags: ["daily"] },
  { id: 606, word: "por favor", type: "expression", translation: "please", priority: 100, level: "A1", tags: ["greetings", "core"] },
  { id: 607, word: "muchas gracias", type: "expression", translation: "thank you very much", priority: 100, level: "A1", tags: ["greetings", "core"] },
  { id: 608, word: "de nada", type: "expression", translation: "you're welcome", priority: 100, level: "A1", tags: ["greetings", "core"] },
  { id: 609, word: "lo siento", type: "expression", translation: "I'm sorry", priority: 100, level: "A1", tags: ["greetings", "core"] },
  { id: 610, word: "hasta luego", type: "expression", translation: "see you later", priority: 100, level: "A1", tags: ["greetings", "core"] },
];

// ============================================================
// LEXICAL FAMILIES
// ============================================================

export const LEXICAL_FAMILIES = {
  comer: ["comida", "comedor", "comestible", "comensal"],
  hablar: ["hablante", "hablador", "habla"],
  escribir: ["escritor", "escritura", "escrito", "escribano"],
  leer: ["lector", "lectura", "leído"],
  trabajo: ["trabajador", "trabajar", "trabajable"],
  estudiar: ["estudiante", "estudio", "estudioso"],
  casa: ["casero", "casita", "casona"],
  perro: ["perrito", "perrera", "perruno"],
  gato: ["gatito", "gatuno", "gatera"],
  familia: ["familiar", "familión", "familiares"],
  ciudad: ["ciudadano", "ciudadela", "ciudadanía"],
  mundo: ["mundial", "mundano", "mundialmente"],
  tiempo: ["temporal", "temporada", "temporario"],
  día: ["diario", "diurno", "diariamente"],
  noche: ["nocturno", "nochero", "anochecer"],
  año: ["anual", "añero", "aniversario"]
};

// ============================================================
// CATEGORIES
// ============================================================

export const CATEGORIES = {
  core: { label: "Core Vocabulary", icon: "⭐", level: "A1" },
  daily: { label: "Daily Life", icon: "☀️", level: "A1" },
  food: { label: "Food & Drink", icon: "🍽️", level: "A1" },
  animals: { label: "Animals", icon: "🐾", level: "A1" },
  colors: { label: "Colors", icon: "🎨", level: "A1" },
  people: { label: "People & Family", icon: "👨‍👩‍👧", level: "A1" },
  places: { label: "Places", icon: "📍", level: "A1" },
  time: { label: "Time", icon: "⏰", level: "A1" },
  education: { label: "Education", icon: "📚", level: "A1" },
  work: { label: "Work", icon: "💼", level: "A1" },
  emotions: { label: "Emotions", icon: "😊", level: "A1" },
  weather: { label: "Weather", icon: "🌤️", level: "A1" },
  greetings: { label: "Greetings", icon: "👋", level: "A1" },
  intermediate: { label: "Intermediate", icon: "📖", level: "B1" },
  advanced: { label: "Advanced", icon: "🎯", level: "C1" },
  slang: { label: "Slang", icon: "💬", level: "B2" },
  idioms: { label: "Idioms", icon: "💡", level: "B2" }
};

// ============================================================
// CEFR LEVEL MAPPING
// ============================================================

export const CEFR_LEVELS = {
  A1: { label: "Beginner", description: "Basic phrases, simple questions" },
  A2: { label: "Elementary", description: "Daily conversations, basic needs" },
  B1: { label: "Intermediate", description: "Travel, work, opinions" },
  B2: { label: "Upper Intermediate", description: "Complex topics, debates" },
  C1: { label: "Advanced", description: "Professional, academic" },
  C2: { label: "Mastery", description: "Native-like fluency" }
};

// ============================================================
// DATABASE HELPERS
// ============================================================

// Build a fast lookup index
export function buildWordIndex() {
  const index = {};
  for (const entry of WORDS) {
    // Index by word
    index[entry.word] = entry;
    // Index by English
    index[entry.english] = entry;
    // Index by ID
    index[entry.id] = entry;
  }
  return index;
}

export const WORD_INDEX = buildWordIndex();

// Get word by Spanish term
export function getWord(word) {
  return WORD_INDEX[word.toLowerCase()] || null;
}

// Get words by category
export function getWordsByCategory(tag) {
  return WORDS.filter(w => w.tags && w.tags.includes(tag));
}

// Get words by level
export function getWordsByLevel(level) {
  return WORDS.filter(w => w.level === level);
}

// Get words by frequency range (min-max)
export function getWordsByFrequency(min, max) {
  return WORDS.filter(w => w.frequency >= min && w.frequency <= max);
}

// Get lexical family for a word
export function getLexicalFamily(word) {
  const lower = word.toLowerCase();
  for (const [base, family] of Object.entries(LEXICAL_FAMILIES)) {
    if (family.includes(lower) || lower === base) {
      return { base, family };
    }
  }
  return null;
}

// Get related words (from lexical family)
export function getRelatedWords(word) {
  const family = getLexicalFamily(word);
  if (!family) return [];
  return family.family.filter(w => w !== word);
}

// Search database
export function searchDatabase(query) {
  const q = query.toLowerCase().trim();
  if (!q) return [];
  
  return WORDS.filter(w => 
    w.word.toLowerCase().includes(q) ||
    w.english.toLowerCase().includes(q) ||
    (w.tags && w.tags.some(tag => tag.toLowerCase().includes(q)))
  );
}

// Get all unique tags
export function getAllTags() {
  const tags = new Set();
  for (const w of WORDS) {
    if (w.tags) {
      w.tags.forEach(tag => tags.add(tag));
    }
  }
  return Array.from(tags);
}

// Export everything as a single database object
export const LANGUAGE_DATABASE = {
  words: WORDS,
  index: WORD_INDEX,
  categories: CATEGORIES,
  cefrLevels: CEFR_LEVELS,
  lexicalFamilies: LEXICAL_FAMILIES,
  getWord,
  getWordsByCategory,
  getWordsByLevel,
  getWordsByFrequency,
  getLexicalFamily,
  getRelatedWords,
  searchDatabase,
  getAllTags
};