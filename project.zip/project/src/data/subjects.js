// src/data/subjects.js

export const subjects = {
  yo: { person: 1, number: "singular", english: "I" },
  tú: { person: 2, number: "singular", english: "you (informal)" },
  él: { person: 3, number: "singular", english: "he" },
  ella: { person: 3, number: "singular", english: "she" },
  usted: { person: 3, number: "singular", english: "you (formal)" },
  nosotros: { person: 1, number: "plural", english: "we" },
  nosotras: { person: 1, number: "plural", english: "we (f)" },
  vosotros: { person: 2, number: "plural", english: "you all (informal)" },
  vosotras: { person: 2, number: "plural", english: "you all (f)" },
  ellos: { person: 3, number: "plural", english: "they" },
  ellas: { person: 3, number: "plural", english: "they (f)" },
  ustedes: { person: 3, number: "plural", english: "you all (formal)" }
};

export function getSubjectData(word) {
  const lower = word.toLowerCase();
  return subjects[lower] || null;
}

export function getSubjectFromPerson(person, number = "singular") {
  for (const [key, data] of Object.entries(subjects)) {
    if (data.person === person && data.number === number) {
      return key;
    }
  }
  return null;
}