// src/data/decks.js
import { generateNumbersDeck } from "./numbers";

export const PRESET_DECKS = [
  {
    id: "deck_greetings",
    name: "Greetings",
    icon: "👋",
    cards: [
      { front: "hola", back: "hello", tags: ["greetings"] },
      { front: "adiós", back: "goodbye", tags: ["greetings"] },
      { front: "buenos días", back: "good morning", tags: ["greetings"] },
      { front: "buenas tardes", back: "good afternoon", tags: ["greetings"] },
      { front: "buenas noches", back: "good evening / good night", tags: ["greetings"] },
    ]
  },
  {
    id: "deck_numbers",
    name: "Numbers 0–100",
    icon: "🔢",
    cards: generateNumbersDeck()
  },
  {
    id: "deck_food",
    name: "Food & Drink",
    icon: "🍽️",
    cards: [
      { front: "comida", back: "food", tags: ["food"] },
      { front: "agua", back: "water", tags: ["food"] },
      { front: "pan", back: "bread", tags: ["food"] },
      { front: "queso", back: "cheese", tags: ["food"] },
      { front: "leche", back: "milk", tags: ["food"] },
    ]
  },
  // ... (other decks remain the same)
];